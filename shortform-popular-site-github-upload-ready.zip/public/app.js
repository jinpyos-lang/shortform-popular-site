const state = {
  data: null,
  config: null,
  authConfig: null,
  user: null,
  section: 'overview',
  filters: { platform: '', eligibility: '', search: '' },
  busy: false
};

const $ = (id) => document.getElementById(id);

const fallbackConfig = {
  version: '1.3.0',
  pages: {
    overview: { title: '오늘의 현황', kicker: '이번 주 운영', description: '현재 수집과 확인 진행 상태를 한눈에 봅니다.' },
    content: { title: '영상 확인하기', kicker: '최종 확인', description: 'AI가 모은 영상이 실제로 추천할 만한지 확인합니다.' },
    rankings: { title: '인기 순위', kicker: '플랫폼별 상위 영상', description: '세 플랫폼의 상위 영상을 비교합니다.' },
    patterns: { title: '성공 공식', kicker: '인기 비결 모음', description: '반복해서 성과를 낸 구성과 표현 방법을 확인합니다.' },
    runs: { title: '자동화 기록', kicker: '수집 작업 결과', description: '자동 수집이 언제 어떻게 작동했는지 확인합니다.' },
    settings: { title: '연결 및 설정', kicker: '서비스 상태', description: '데이터와 플랫폼 연결을 확인합니다.' }
  },
  eligibility: {
    Eligible: { label: '추천', description: '주간 인기 목록에 포함', tone: 'good' },
    Review: { label: '다시 확인', description: '추가 확인 필요', tone: 'warning' },
    Excluded: { label: '제외', description: '주간 목록에서 제외', tone: 'danger' }
  },
  analysisStatus: { Pending: '확인 전', Collected: '정보 수집 완료', Analyzed: 'AI 분석 완료', Reviewed: '최종 확인 완료', Excluded: '제외 완료' },
  runStatus: { Planned: '시작 대기', Running: '수집 중', Succeeded: '정상 완료', Partial: '일부 완료', Failed: '문제 발생' },
  runType: { Collection: '인기 영상 수집', Analysis: '영상 분석', Review: '최종 확인', Publish: '리포트 만들기', Pilot: '시험 실행' },
  patternDecision: { Continue: '계속 활용', Improve: '보완 후 활용', Discard: '사용 중지', 지속: '계속 활용', 개선: '보완 후 활용', 폐기: '사용 중지' },
  patternConfidence: { High: '높음', Medium: '보통', Low: '낮음', 높음: '높음', 중간: '보통', 낮음: '낮음' },
  pipeline: [
    { name: '인기 영상 찾기', description: '세 플랫폼에서 이번 주 후보 영상을 모읍니다.' },
    { name: '중복 영상 정리', description: '같은 영상과 단순 재업로드를 제거합니다.' },
    { name: '인기 점수 계산', description: '조회 속도와 참여 반응을 공정하게 비교합니다.' },
    { name: '사람이 최종 확인', description: '광고성, 한국 관련성, 원본 여부를 확인합니다.' },
    { name: '인기 비결 분석', description: '훅, 전개, 자막, 오디오, 댓글 반응을 분석합니다.' },
    { name: '주간 리포트 작성', description: '상위 영상과 핵심 인사이트를 Notion에 정리합니다.' },
    { name: '다음 제작 방향 결정', description: '계속 활용, 보완, 사용 중지를 결정합니다.' },
    { name: '다음 주 기준 개선', description: '분석 결과를 다음 수집과 평가에 반영합니다.' }
  ]
};

async function loadUiConfig() {
  try {
    const response = await fetch('/ui-config.json', { cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    state.config = await response.json();
  } catch {
    state.config = fallbackConfig;
  }
}

async function loadAuthConfig() {
  try {
    const response = await fetch('/api/auth/config', { cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    state.authConfig = await response.json();
  } catch {
    state.authConfig = { notionOAuthEnabled: false, passwordLoginEnabled: true };
  }
}

async function api(path, options = {}) {
  const token = sessionStorage.getItem('cic_token');
  const response = await fetch(path, {
    ...options,
    headers: {
      ...(options.body ? { 'content-type': 'application/json' } : {}),
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401 && !path.startsWith('/api/auth/')) {
      sessionStorage.removeItem('cic_token');
      showLogin();
    }
    const error = new Error(body.message || body.error || `HTTP ${response.status}`);
    error.code = body.error;
    error.status = response.status;
    throw error;
  }
  return body;
}

function friendlyError(error) {
  const messages = {
    INVALID_PASSWORD: '비밀번호가 올바르지 않습니다.',
    UNAUTHORIZED: '로그인이 만료되었습니다. 다시 로그인해 주세요.',
    UNTRUSTED_ORIGIN: '허용되지 않은 화면에서 요청했습니다. 이 사이트를 새로 열어 주세요.',
    TOO_MANY_LOGIN_ATTEMPTS: '로그인 시도가 너무 많습니다. 잠시 후 다시 시도해 주세요.',
    CONTENT_NOT_FOUND: '선택한 영상을 찾을 수 없습니다. 최신 내용을 불러온 뒤 다시 시도해 주세요.',
    INVALID_ELIGIBILITY: '영상 처리 결과를 다시 선택해 주세요.',
    INVALID_ANALYSIS_STATUS: '확인 진행 상태를 다시 선택해 주세요.',
    PASSWORD_LOGIN_DISABLED: '비밀번호 로그인이 꺼져 있습니다. Notion 계정으로 로그인해 주세요.',
    NOTION_OAUTH_NOT_CONFIGURED: 'Notion 계정 로그인이 아직 연결되지 않았습니다.',
    NOTION_OAUTH_EXCHANGE_FAILED: 'Notion 로그인 승인 정보를 확인하지 못했습니다.',
    NOTION_WORKSPACE_NOT_ALLOWED: '허용된 Notion 워크스페이스가 아닙니다.',
    NOTION_USER_NOT_ALLOWED: '이 Notion 계정은 사이트 사용 권한이 없습니다.',
    NOTION_IDENTITY_MISSING: 'Notion 계정 정보를 확인할 수 없습니다.',
    INTERNAL_ERROR: '처리 중 문제가 발생했습니다. 자동화 기록과 연결 상태를 확인해 주세요.'
  };
  return messages[error.code] || error.message || '요청을 처리하지 못했습니다.';
}

function toast(message, type = 'info') {
  const element = $('toast');
  element.textContent = message;
  element.dataset.type = type;
  element.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.add('hidden'), 4200);
}

function setBusy(busy, message = '') {
  state.busy = busy;
  ['runBtn', 'runLogBtn', 'saveReviewBtn', 'refreshBtn'].forEach((id) => {
    const button = $(id);
    if (button) button.disabled = busy;
  });
  if (message) $('modeBadge').textContent = message;
}

function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;'
  }[character]));
}

function safeUrl(value = '') {
  if (!value || String(value).startsWith('#')) return '';
  try {
    const url = new URL(value, window.location.origin);
    return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
  } catch {
    return '';
  }
}

function youtubeVideoId(value = '') {
  try {
    const url = new URL(value);
    if (url.hostname === 'youtu.be') return url.pathname.split('/').filter(Boolean)[0] || '';
    if (url.pathname.startsWith('/shorts/')) return url.pathname.split('/')[2] || '';
    if (url.pathname.startsWith('/embed/')) return url.pathname.split('/')[2] || '';
    return url.searchParams.get('v') || '';
  } catch {
    return '';
  }
}

function xmlText(value = '') {
  return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[character]));
}

function thumbnailPlaceholder(item = {}) {
  const palette = item.platform === 'TikTok' ? ['#101010', '#25f4ee'] : item.platform === 'Instagram Reels' ? ['#7c3aed', '#f97316'] : ['#ef4444', '#991b1b'];
  const platform = xmlText(item.platform || '숏폼 영상');
  const title = xmlText(String(item.title || '영상 미리보기').slice(0, 30));
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360"><defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="${palette[0]}"/><stop offset="1" stop-color="${palette[1]}"/></linearGradient></defs><rect width="640" height="360" fill="url(#g)"/><circle cx="320" cy="145" r="48" fill="rgba(255,255,255,.9)"/><path d="M305 118 350 145 305 172Z" fill="${palette[0]}"/><text x="32" y="42" fill="white" font-size="22" font-family="Arial,sans-serif" font-weight="700">${platform}</text><text x="32" y="324" fill="white" font-size="25" font-family="Arial,sans-serif" font-weight="700">${title}</text></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function thumbnailFor(item = {}) {
  const explicit = safeUrl(item.thumbnailUrl);
  if (explicit) return explicit;
  const id = youtubeVideoId(item.url);
  if (id) return `https://i.ytimg.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`;
  return thumbnailPlaceholder(item);
}

function thumbnailMarkup(item, className = 'video-thumbnail') {
  const source = thumbnailFor(item);
  const fallback = thumbnailPlaceholder(item);
  return `<img class="${className}" src="${escapeHtml(source)}" data-fallback="${escapeHtml(fallback)}" alt="${escapeHtml(item.title || item.platform || '영상')} 썸네일" loading="lazy" decoding="async" referrerpolicy="no-referrer" />`;
}

function activateThumbnailFallbacks(container) {
  container.querySelectorAll('img[data-fallback]').forEach((image) => {
    image.addEventListener('error', () => {
      const fallback = image.dataset.fallback;
      if (fallback && image.src !== fallback) image.src = fallback;
    }, { once: true });
  });
}

function formatNumber(value) {
  const number = Number(value) || 0;
  return new Intl.NumberFormat('ko-KR', {
    notation: Math.abs(number) >= 1_000_000 ? 'compact' : 'standard',
    maximumFractionDigits: 1
  }).format(number);
}

function formatPercent(value) {
  return new Intl.NumberFormat('ko-KR', { style: 'percent', maximumFractionDigits: 1 }).format(Number(value) || 0);
}

function formatDateTime(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat('ko-KR', {
    timeZone: 'Asia/Seoul', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
  }).format(date);
}

function getField(object, names, fallback = '') {
  for (const name of names) {
    if (object?.[name] !== undefined && object[name] !== '') return object[name];
  }
  return fallback;
}

function eligibilityInfo(value) {
  return state.config?.eligibility?.[value] || { label: value || '다시 확인', description: '', tone: 'neutral' };
}

function statusLabel(value) {
  return state.config?.analysisStatus?.[value] || value || '확인 전';
}

function runStatusInfo(value) {
  const label = state.config?.runStatus?.[value] || value || '-';
  const tone = value === 'Succeeded' ? 'good' : value === 'Failed' ? 'danger' : ['Partial', 'Planned'].includes(value) ? 'warning' : 'neutral';
  return { label, tone };
}

async function boot() {
  await Promise.all([loadUiConfig(), loadAuthConfig()]);
  const authError = new URLSearchParams(window.location.search).get('authError');
  if (authError) {
    const error = new Error(authError);
    error.code = authError;
    $('loginError').textContent = friendlyError(error);
    history.replaceState({}, '', window.location.pathname);
  }
  try {
    const session = await api('/api/auth/session');
    if (!session.authenticated) return showLogin();
    state.user = session.user;
    showApp();
    await loadData();
  } catch (error) {
    showLogin();
    $('loginError').textContent = `사이트 연결 오류: ${friendlyError(error)}`;
  }
}

function showLogin() {
  $('loginView').classList.remove('hidden');
  $('appView').classList.add('hidden');
  $('notionLoginBtn').classList.toggle('hidden', !state.authConfig?.notionOAuthEnabled);
  $('notionLoginHelp').classList.toggle('hidden', !state.authConfig?.notionOAuthEnabled);
  $('passwordLoginBox').classList.toggle('hidden', !state.authConfig?.passwordLoginEnabled);
  if (!state.authConfig?.notionOAuthEnabled && state.authConfig?.passwordLoginEnabled) $('passwordLoginBox').open = true;
  setTimeout(() => !state.authConfig?.notionOAuthEnabled && $('password')?.focus({ preventScroll: true }), 0);
}

function renderUserProfile() {
  const user = state.user;
  $('userProfile').classList.toggle('hidden', !user);
  if (!user) return;
  $('userName').textContent = user.name || 'Notion 사용자';
  $('workspaceName').textContent = user.workspaceName || (user.provider === 'notion' ? 'Notion 계정' : '관리자 로그인');
  const avatar = safeUrl(user.avatarUrl) || thumbnailPlaceholder({ platform: 'Notion', title: (user.name || 'N').slice(0, 1) });
  $('userAvatar').src = avatar;
  $('userAvatar').alt = `${user.name || '사용자'} 프로필`;
}

function showApp() {
  $('loginView').classList.add('hidden');
  $('appView').classList.remove('hidden');
  renderUserProfile();
}

async function fetchDashboard() {
  state.data = await api('/api/dashboard');
  renderAll();
  updateModeBadge();
}

async function loadData() {
  if (state.busy) return;
  setBusy(true, '내용 불러오는 중');
  try {
    await fetchDashboard();
  } catch (error) {
    toast(`내용을 불러오지 못했습니다: ${friendlyError(error)}`, 'error');
    $('modeBadge').textContent = '연결 문제';
    $('modeBadge').className = 'connection-badge error';
  } finally {
    setBusy(false);
  }
}

function updateModeBadge() {
  const live = state.data?.mode === 'live';
  $('modeBadge').textContent = live ? '실제 데이터 연결' : '체험 화면';
  $('modeBadge').className = `connection-badge ${live ? 'live' : 'mock'}`;
}

function renderAll() {
  renderScope();
  renderStats();
  renderNextActions();
  renderTopContent();
  renderPipeline();
  renderContent();
  renderRankings();
  renderPatterns();
  renderRuns();
  renderConnections();
}

function renderScope() {
  const scope = state.data.scope;
  $('scopeSummary').textContent = `${scope.market} · ${scope.language} · ${scope.category} · ${scope.output} · ${scope.window}`;
}

function renderStats() {
  const kpis = state.data.kpis;
  const items = [
    ['모은 영상', kpis.rawItems, '이번 주 후보'],
    ['분석 완료', kpis.analyzedItems, 'AI 분석이 끝남'],
    ['순위 등록', kpis.rankedItems, '상위 목록에 반영'],
    ['성공 공식', kpis.patterns, '반복된 인기 요소'],
    ['추천 영상', kpis.eligibleItems, '목록에 바로 포함'],
    ['확인 필요', kpis.reviewItems, '사람이 추가 확인']
  ];
  $('kpiGrid').innerHTML = items.map(([label, value, help]) => `
    <article class="stat-card"><span>${escapeHtml(label)}</span><strong>${formatNumber(value)}</strong><small>${escapeHtml(help)}</small></article>
  `).join('');
}

function renderNextActions() {
  const kpis = state.data.kpis;
  const actions = [];
  if (!kpis.rawItems) actions.push({ section: 'overview', run: true, title: '이번 주 인기 영상을 먼저 찾아보세요', detail: 'TikTok, YouTube Shorts, Instagram Reels에서 후보를 모읍니다.' });
  if (kpis.reviewItems) actions.push({ section: 'content', title: `${formatNumber(kpis.reviewItems)}개 영상을 확인해 주세요`, detail: '광고, 중복, 한국 관련성을 보고 추천 여부를 결정합니다.' });
  if (kpis.rawItems) actions.push({ section: 'rankings', title: '현재 인기 순위를 확인하세요', detail: '플랫폼별 점수가 높은 영상과 원본을 볼 수 있습니다.' });
  if (kpis.patterns) actions.push({ section: 'patterns', title: `${formatNumber(kpis.patterns)}개의 성공 공식을 활용하세요`, detail: '다음 영상의 훅과 구성 아이디어로 사용할 수 있습니다.' });
  if (!actions.length) actions.push({ section: 'overview', run: true, title: '새로운 주간 수집을 시작하세요', detail: '최신 인기 영상으로 내용을 갱신합니다.' });

  $('nextActions').innerHTML = actions.slice(0, 3).map((action, index) => `
    <button class="next-action" data-go="${escapeHtml(action.section)}" ${action.run ? 'data-run="true"' : ''}>
      <span class="action-number">${index + 1}</span>
      <span><strong>${escapeHtml(action.title)}</strong><small>${escapeHtml(action.detail)}</small></span>
      <span class="action-arrow">›</span>
    </button>
  `).join('');
}

function renderTopContent() {
  const items = [...state.data.content].sort((a, b) => Number(b.totalScore) - Number(a.totalScore)).slice(0, 5);
  $('topContent').innerHTML = items.length ? items.map((item, index) => {
    const url = safeUrl(item.url);
    const title = url
      ? `<a class="top-title" href="${escapeHtml(url)}" target="_blank" rel="noreferrer">${escapeHtml(item.title || item.id)}</a>`
      : `<span class="top-title">${escapeHtml(item.title || item.id)}</span>`;
    return `<div class="top-item"><span class="rank-number">${index + 1}</span>${thumbnailMarkup(item, 'top-thumb')}<div>${title}<div class="item-meta">${escapeHtml(item.platform)} · ${escapeHtml(item.creator || '만든 사람 미확인')} · 조회 ${formatNumber(item.views)}</div></div><div class="score-box"><strong>${Number(item.totalScore || 0).toFixed(1)}</strong><small>인기 점수</small></div></div>`;
  }).join('') : '<div class="empty-state">아직 수집된 영상이 없습니다.</div>';
  activateThumbnailFallbacks($('topContent'));
}

function renderPipeline() {
  const configured = state.config.pipeline?.length ? state.config.pipeline : fallbackConfig.pipeline;
  const raw = state.data.kpis.rawItems > 0;
  const analyzed = state.data.kpis.analyzedItems > 0;
  const ranked = state.data.kpis.rankedItems > 0;
  const patterns = state.data.kpis.patterns > 0;

  $('pipeline').innerHTML = configured.map((step, index) => {
    let stateName = 'waiting';
    let label = '대기';
    if ((index <= 1 && raw) || (index === 2 && analyzed) || (index === 3 && analyzed) || (index === 4 && analyzed) || (index === 5 && ranked) || (index >= 6 && patterns)) {
      stateName = 'done';
      label = '완료';
    } else if ((index === 0 && !raw) || (index >= 2 && raw && !analyzed) || (index >= 5 && analyzed && !ranked)) {
      stateName = 'active';
      label = '진행 가능';
    }
    return `<article class="process-step ${stateName}"><div class="process-top"><span class="process-index">STEP ${index + 1}</span><span class="process-status">${label}</span></div><h3>${escapeHtml(step.name)}</h3><p>${escapeHtml(step.description)}</p></article>`;
  }).join('');
}

function filteredContent() {
  const query = state.filters.search.trim().toLowerCase();
  return state.data.content.filter((item) => (
    (!state.filters.platform || item.platform === state.filters.platform)
    && (!state.filters.eligibility || item.eligibility === state.filters.eligibility)
    && (!query || `${item.title} ${item.creator} ${item.id}`.toLowerCase().includes(query))
  ));
}

function renderContent() {
  const rows = filteredContent();
  $('contentList').innerHTML = rows.length ? rows.map((item) => {
    const eligibility = eligibilityInfo(item.eligibility);
    const url = safeUrl(item.url);
    const title = url
      ? `<a href="${escapeHtml(url)}" target="_blank" rel="noreferrer">${escapeHtml(item.title || item.id)}</a>`
      : escapeHtml(item.title || item.id);
    return `<article class="video-card">
      <div class="video-thumbnail-wrap">${thumbnailMarkup(item)}<span class="video-thumbnail-badge">${escapeHtml(item.platform || '숏폼')}</span></div>
      <div class="video-card-top"><span class="platform-chip">${escapeHtml(item.platform || '플랫폼 미확인')}</span><span class="status-chip ${escapeHtml(eligibility.tone)}">${escapeHtml(eligibility.label)}</span></div>
      <h3>${title}</h3>
      <div class="video-creator">${escapeHtml(item.creator || '만든 사람 미확인')} · ${escapeHtml(item.category || '장르 미분류')}</div>
      <div class="video-metrics">
        <div class="metric"><span>인기 점수</span><strong>${Number(item.totalScore || 0).toFixed(1)}</strong></div>
        <div class="metric"><span>조회수</span><strong>${formatNumber(item.views)}</strong></div>
        <div class="metric"><span>참여율</span><strong>${formatPercent(item.engagementRate)}</strong></div>
      </div>
      <div class="video-card-footer"><span class="analysis-label">${escapeHtml(statusLabel(item.status))} · 한국 관련성 ${formatNumber(item.relevance)}</span><button class="button button-secondary review-button" data-id="${escapeHtml(item.id)}">확인하기</button></div>
    </article>`;
  }).join('') : '<div class="empty-state">선택한 조건에 맞는 영상이 없습니다.</div>';

  activateThumbnailFallbacks($('contentList'));
  document.querySelectorAll('.review-button').forEach((button) => button.addEventListener('click', () => openReview(button.dataset.id)));
}

function normalizedRankings(platform) {
  const contentById = new Map(state.data.content.map((item) => [item.id, item]));
  const sourceRankings = (state.data.rankings || []).filter((row) => getField(row, ['Platform', '플랫폼']) === platform);
  if (sourceRankings.length) {
    return sourceRankings
      .sort((a, b) => Number(getField(a, ['Rank', '순위'], 999)) - Number(getField(b, ['Rank', '순위'], 999)))
      .map((row) => contentById.get(getField(row, ['Content ID', '콘텐츠 ID'])) || {
        id: getField(row, ['Content ID', '콘텐츠 ID'], '-'),
        title: getField(row, ['Title', '콘텐츠명', '제목'], getField(row, ['Content ID', '콘텐츠 ID'], '제목 없음')),
        creator: getField(row, ['Creator', '크리에이터'], ''),
        totalScore: Number(getField(row, ['Total Score', '총점'], 0)),
        platform
      });
  }
  return state.data.content.filter((item) => item.platform === platform).sort((a, b) => Number(b.totalScore) - Number(a.totalScore)).slice(0, 5);
}

function renderRankings() {
  const platforms = ['TikTok', 'YouTube Shorts', 'Instagram Reels'];
  $('rankingBoards').innerHTML = platforms.map((platform) => {
    const items = normalizedRankings(platform).slice(0, 5);
    const rows = items.length ? items.map((item, index) => `
      <div class="ranking-row"><span class="ranking-row-number">${index + 1}</span>${thumbnailMarkup(item, 'ranking-thumb')}<div><div class="ranking-name" title="${escapeHtml(item.title || item.id)}">${escapeHtml(item.title || item.id)}</div><div class="ranking-creator">${escapeHtml(item.creator || '만든 사람 미확인')}</div></div><span class="ranking-score">${Number(item.totalScore || 0).toFixed(1)}</span></div>
    `).join('') : '<div class="empty-state">아직 순위가 없습니다.</div>';
    return `<section class="ranking-board"><h3>${escapeHtml(platform)}</h3>${rows}</section>`;
  }).join('');
  activateThumbnailFallbacks($('rankingBoards'));
}

function renderPatterns() {
  const patterns = state.data.patterns || [];
  $('patternGrid').innerHTML = patterns.length ? patterns.map((pattern) => {
    const name = getField(pattern, ['Pattern Name', '패턴명'], '이름 없는 성공 공식');
    const category = getField(pattern, ['Category', '카테고리'], '인기 요소');
    const platforms = getField(pattern, ['Platforms', '플랫폼'], '여러 플랫폼');
    const confidence = getField(pattern, ['Confidence', '신뢰도'], '-');
    const decision = getField(pattern, ['Decision', '판정'], '-');
    const successRate = getField(pattern, ['Success Rate', '성공률'], '');
    return `<article class="pattern-card"><span class="status-chip neutral">${escapeHtml(category)}</span><h3>${escapeHtml(name)}</h3><p class="supporting-text">활용 플랫폼: ${escapeHtml(platforms)}</p><div class="pattern-info"><div class="info-row"><span>근거 신뢰도</span><strong>${escapeHtml(state.config.patternConfidence?.[confidence] || confidence)}</strong></div><div class="info-row"><span>활용 결정</span><strong>${escapeHtml(state.config.patternDecision?.[decision] || decision)}</strong></div>${successRate !== '' ? `<div class="info-row"><span>성공률</span><strong>${escapeHtml(String(successRate))}</strong></div>` : ''}</div></article>`;
  }).join('') : '<div class="empty-state">아직 반복해서 확인된 성공 공식이 없습니다.</div>';
}

function renderRuns() {
  const runs = state.data.runs || [];
  $('runList').innerHTML = runs.length ? runs.map((run) => {
    const status = getField(run, ['Status', '상태'], 'Planned');
    const statusInfo = runStatusInfo(status);
    const type = getField(run, ['Run Type', '실행 유형'], 'Collection');
    return `<article class="run-card">
      <div class="run-main"><strong>${escapeHtml(state.config.runType?.[type] || type)}</strong><small>${escapeHtml(getField(run, ['Run ID', '실행 ID'], '작업 번호 없음'))} · ${escapeHtml(getField(run, ['Week', '주차'], '-'))}</small></div>
      <div><span class="status-chip ${escapeHtml(statusInfo.tone)}">${escapeHtml(statusInfo.label)}</span></div>
      <div class="run-stat"><span>찾은 영상</span><strong>${formatNumber(getField(run, ['Items Read', '읽은 항목'], 0))}</strong></div>
      <div class="run-stat"><span>선택 영상</span><strong>${formatNumber(getField(run, ['Items Accepted', '채택 항목'], 0))}</strong></div>
      <div class="run-stat"><span>문제 수</span><strong>${formatNumber(getField(run, ['Errors', '오류'], 0))}</strong></div>
      <div class="run-note">${escapeHtml(getField(run, ['Notes', '메모'], '기록된 안내가 없습니다.'))}</div>
    </article>`;
  }).join('') : '<div class="empty-state">아직 자동화 실행 기록이 없습니다.</div>';
}

async function renderConnections() {
  try {
    const health = await api(`/api/health${state.data?.mode === 'live' ? '?deep=1' : ''}`);
    const items = [
      ['원본 데이터 표', health.connections?.sheets?.ok ?? health.sheetsConfigured],
      ['Notion 운영 페이지', health.connections?.notion?.ok ?? health.notionConfigured],
      ['YouTube 영상 찾기', health.providersConfigured?.youtube],
      ['TikTok 영상 찾기', health.providersConfigured?.tiktok],
      ['Instagram 영상 찾기', health.providersConfigured?.instagram]
    ];
    $('connectionState').innerHTML = items.map(([name, ready]) => `<div class="connection-row"><span>${escapeHtml(name)}</span><strong class="connection-value ${ready ? 'ready' : 'needs'}">${ready ? '사용 가능' : '설정 필요'}</strong></div>`).join('')
      + `<div class="connection-row"><span>사이트 버전</span><strong>${escapeHtml(health.version || state.config.version || '-')}</strong></div>`;
  } catch (error) {
    $('connectionState').innerHTML = `<p class="form-message error">연결 상태를 확인하지 못했습니다: ${escapeHtml(friendlyError(error))}</p>`;
  }
}

function openReview(id) {
  const item = state.data.content.find((entry) => entry.id === id);
  if (!item) return;
  $('reviewRow').value = item.row;
  $('reviewContentId').value = item.id;
  $('reviewTitle').textContent = item.title || item.id;
  $('reviewMeta').textContent = `${item.platform || '플랫폼 미확인'} · ${item.creator || '만든 사람 미확인'} · 인기 점수 ${Number(item.totalScore || 0).toFixed(1)}`;
  $('reviewEligibility').value = item.eligibility || 'Review';
  $('reviewStatus').value = item.status || 'Pending';
  $('reviewNotes').value = item.notes || '';
  $('reviewDialog').showModal();
}

async function saveReview(event) {
  event.preventDefault();
  if (state.busy) return;
  const payload = {
    row: Number($('reviewRow').value),
    contentId: $('reviewContentId').value,
    eligibility: $('reviewEligibility').value,
    status: $('reviewStatus').value,
    notes: $('reviewNotes').value
  };
  setBusy(true, '확인 결과 저장 중');
  try {
    const result = await api('/api/content/decision', { method: 'PATCH', body: JSON.stringify(payload) });
    $('reviewDialog').close();
    if (result.notion?.error) toast(`원본 데이터에는 저장됐지만 Notion 연결에 문제가 있습니다: ${result.notion.error}`, 'warning');
    else toast('확인 결과를 원본 데이터와 Notion에 저장했습니다.', 'success');
    await fetchDashboard();
  } catch (error) {
    toast(`저장하지 못했습니다: ${friendlyError(error)}`, 'error');
  } finally {
    setBusy(false);
  }
}

async function registerRun() {
  if (state.busy) return;
  setBusy(true, '인기 영상 찾는 중');
  try {
    const run = await api('/api/runs', { method: 'POST', body: JSON.stringify({ type: 'Collection', week: 'AUTO' }) });
    const statusInfo = runStatusInfo(run.status || 'Partial');
    toast(`${statusInfo.label}: ${formatNumber(run.itemsAccepted || 0)}개 영상을 선택했습니다.`, run.status === 'Failed' ? 'error' : 'success');
    await fetchDashboard();
  } catch (error) {
    toast(`영상 수집을 시작하지 못했습니다: ${friendlyError(error)}`, 'error');
  } finally {
    setBusy(false);
  }
}

function navigate(section) {
  state.section = section;
  document.querySelectorAll('.page-section').forEach((element) => element.classList.toggle('active', element.id === section));
  document.querySelectorAll('.nav-button').forEach((element) => element.classList.toggle('active', element.dataset.section === section));
  const page = state.config.pages?.[section] || fallbackConfig.pages[section];
  $('pageTitle').textContent = page?.title || '숏폼 인기영상';
  $('pageKicker').textContent = page?.kicker || '운영 사이트';
  $('pageDescription').textContent = page?.description || '';
  $('sidebar').classList.remove('open');
  $('menuBtn').setAttribute('aria-expanded', 'false');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

$('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('loginError').textContent = '';
  const submitButton = event.submitter;
  if (submitButton) submitButton.disabled = true;
  try {
    const result = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ password: $('password').value }) });
    if (result.token) sessionStorage.setItem('cic_token', result.token);
    state.user = result.user || { provider: 'password', name: '운영자' };
    $('password').value = '';
    showApp();
    await loadData();
  } catch (error) {
    $('loginError').textContent = friendlyError(error);
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
});

$('logoutBtn').addEventListener('click', async () => {
  try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* 브라우저 세션은 아래에서 삭제 */ }
  sessionStorage.removeItem('cic_token');
  state.user = null;
  showLogin();
});

$('notionLoginBtn').addEventListener('click', (event) => {
  if (window.self !== window.top) {
    event.preventDefault();
    window.open($('notionLoginBtn').href, '_blank', 'noopener,noreferrer');
    $('loginError').textContent = '새 창에서 Notion 로그인을 마친 뒤 이 화면을 새로고침해 주세요.';
  }
});

$('refreshBtn').addEventListener('click', loadData);
$('runBtn').addEventListener('click', registerRun);
$('runLogBtn').addEventListener('click', registerRun);
$('menuBtn').addEventListener('click', () => {
  const open = $('sidebar').classList.toggle('open');
  $('menuBtn').setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('.nav-button').forEach((button) => button.addEventListener('click', () => navigate(button.dataset.section)));
document.addEventListener('click', (event) => {
  const target = event.target.closest('[data-go]');
  if (!target) return;
  if (target.dataset.run === 'true') registerRun();
  else navigate(target.dataset.go);
});

$('platformFilter').addEventListener('change', (event) => { state.filters.platform = event.target.value; renderContent(); });
$('eligibilityFilter').addEventListener('change', (event) => { state.filters.eligibility = event.target.value; renderContent(); });
$('contentSearch').addEventListener('input', (event) => { state.filters.search = event.target.value; renderContent(); });
$('reviewForm').addEventListener('submit', saveReview);
$('closeReviewBtn').addEventListener('click', () => $('reviewDialog').close());
$('cancelReviewBtn').addEventListener('click', () => $('reviewDialog').close());
$('reviewDialog').addEventListener('click', (event) => { if (event.target === $('reviewDialog')) $('reviewDialog').close(); });

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && $('sidebar').classList.contains('open')) {
    $('sidebar').classList.remove('open');
    $('menuBtn').setAttribute('aria-expanded', 'false');
  }
});

boot();
