import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { executeCollectionRun, patchContentDecision } from '../src/pipeline.mjs';

const { privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const googleConfig = {
  email: 'service@example.iam.gserviceaccount.com',
  privateKey: privateKey.export({ type: 'pkcs8', format: 'pem' }),
  sheetId: 'sheet-id'
};

test('live pipeline writes formulas, logs, and validated decisions through mocked APIs', async () => {
  const originalFetch = globalThis.fetch;
  const calls = [];
  globalThis.fetch = async (input, init = {}) => {
    const url = String(input);
    const body = init.body && url !== 'https://oauth2.googleapis.com/token' ? JSON.parse(init.body) : null;
    calls.push({ url, method: init.method || 'GET', body });

    if (url === 'https://oauth2.googleapis.com/token') {
      return new Response(JSON.stringify({ access_token: 'token', expires_in: 3600 }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    if (url === 'https://collector.example/tiktok') {
      return new Response(JSON.stringify({ items: [{
        id: 'tt-1', url: 'https://www.tiktok.com/@creator/video/1', creator: '@creator', postedAt: '2026-07-27T01:00:00+09:00',
        durationSec: 20, followers: 10000, views: 500000, likes: 50000, comments: 1000, shares: 500, saves: 300,
        title: '한국어 챌린지 쇼츠', hashtags: ['#챌린지'], category: 'Entertainment', relevance: 100, thumbnailUrl: 'https://img.example/tiktok.jpg'
      }] }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    if (url.includes('/values/Run_Log!A%3AO:append')) {
      return new Response(JSON.stringify({ updates: { updatedRange: 'Run_Log!A2:O2' } }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    if (url.includes('/values:batchGet')) {
      return new Response(JSON.stringify({ valueRanges: [{ range: 'Raw_Content!A2:A500', values: [] }, { range: 'Raw_Content!E2:E500', values: [] }] }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    if (url.includes('/values/Raw_Content!A2%3AAJ2') && (init.method || 'GET') === 'PUT') {
      assert.equal(body.values.length, 1);
      assert.equal(body.values[0].length, 36);
      assert.match(body.values[0][20], /^=IF\(A2=/);
      assert.equal(body.values[0][30], 'Collected');
      assert.equal(body.values[0][34], 'Review');
      assert.equal(body.values[0][35], 'https://img.example/tiktok.jpg');
      return new Response(JSON.stringify({ updatedCells: 36 }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    if (url.includes('/values/Run_Log!D2%3AO2') && init.method === 'PUT') {
      assert.equal(body.values[0][2], 'Succeeded');
      return new Response(JSON.stringify({ updatedCells: 12 }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    if (url.includes('/values/Raw_Content!A2%3AAJ2') && (init.method || 'GET') === 'GET') {
      return new Response(JSON.stringify({ range: 'Raw_Content!A2:AJ2', values: [['KR-TT-EXPECTED']] }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    if (url.endsWith('/values:batchUpdate') && init.method === 'POST') {
      assert.deepEqual(body.data.map((entry) => entry.range), ['Raw_Content!AE2', 'Raw_Content!AF2', 'Raw_Content!AI2']);
      return new Response(JSON.stringify({ totalUpdatedCells: 3 }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    throw new Error(`Unexpected fetch: ${url}`);
  };

  try {
    const result = await executeCollectionRun({
      googleConfig,
      providerConfig: {
        youtube: { apiKey: '', queries: [], maxQueries: 1, maxPerQuery: 1, maxDurationSec: 180 },
        tiktok: { url: 'https://collector.example/tiktok', secret: 'webhook-secret', timeoutMs: 1000 },
        instagram: { url: '', secret: '', timeoutMs: 1000 }
      },
      requestedWeek: '2026-W31',
      requestedBy: 'Test'
    });
    assert.equal(result.status, 'Succeeded');
    assert.equal(result.itemsAccepted, 1);
    assert.ok(calls.some((call) => call.url === 'https://collector.example/tiktok' && call.method === 'POST'));

    const patch = await patchContentDecision(googleConfig, {
      row: 2, contentId: 'KR-TT-EXPECTED', eligibility: 'Eligible', status: 'Reviewed', notes: '사람 검토 완료'
    });
    assert.equal(patch.eligibility, 'Eligible');
  } finally {
    globalThis.fetch = originalFetch;
  }
});
