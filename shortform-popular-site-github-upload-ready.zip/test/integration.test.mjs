import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { getIsoWeekKst } from '../src/time.mjs';

const port = 35000 + (process.pid % 1000);
const base = `http://127.0.0.1:${port}`;
let child;

async function waitForServer() {
  for (let index = 0; index < 80; index += 1) {
    try {
      const response = await fetch(`${base}/api/health`);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error('Server did not start.');
}

async function json(path, options = {}) {
  const response = await fetch(`${base}${path}`, options);
  const body = await response.json().catch(() => ({}));
  return { response, body };
}

test.before(async () => {
  child = spawn(process.execPath, ['server.mjs'], {
    cwd: new URL('..', import.meta.url),
    env: {
      ...process.env,
      PORT: String(port),
      NODE_ENV: 'test',
      DATA_MODE: 'mock',
      MOCK_PUBLIC_PREVIEW: 'false',
      EMBED_MODE: 'false',
      ADMIN_PASSWORD: 'integration-password',
      AUTH_SECRET: 'a'.repeat(48),
      CRON_SECRET: 'b'.repeat(32)
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  child.stderr.on('data', (chunk) => process.stderr.write(chunk));
  await waitForServer();
});

test.after(() => {
  child?.kill('SIGTERM');
});

test('health and security headers are present', async () => {
  const response = await fetch(`${base}/api/health`);
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-security-policy'), /frame-ancestors/);
  const body = await response.json();
  assert.equal(body.version, '1.3.0');
});



test('friendly HTML5 site and JSON terminology load correctly', async () => {
  const page = await fetch(`${base}/`);
  assert.equal(page.status, 200);
  assert.match(page.headers.get('content-type'), /text\/html/);
  const html = await page.text();
  assert.match(html, /숏폼 인기영상 도우미/);
  assert.match(html, /오늘의 현황/);
  assert.match(html, /영상 확인하기/);
  assert.match(html, /성공 공식/);
  assert.match(html, /Notion 계정으로 시작하기/);
  assert.doesNotMatch(html, />대시보드</);

  const configResponse = await fetch(`${base}/ui-config.json`);
  assert.equal(configResponse.status, 200);
  assert.match(configResponse.headers.get('content-type'), /application\/json/);
  const config = await configResponse.json();
  assert.equal(config.version, '1.3.0');
  assert.equal(config.eligibility.Eligible.label, '추천');
  assert.equal(config.analysisStatus.Reviewed, '최종 확인 완료');

  const manifest = await fetch(`${base}/site.webmanifest`);
  assert.equal(manifest.status, 200);
  assert.match(manifest.headers.get('content-type'), /application\/manifest\+json/);
});

test('dashboard requires authentication', async () => {
  const { response, body } = await json('/api/dashboard');
  assert.equal(response.status, 401);
  assert.equal(body.error, 'UNAUTHORIZED');
});

test('untrusted browser origin is rejected', async () => {
  const { response, body } = await json('/api/auth/login', {
    method: 'POST',
    headers: { origin: 'https://attacker.example', 'content-type': 'application/json' },
    body: JSON.stringify({ password: 'integration-password' })
  });
  assert.equal(response.status, 403);
  assert.equal(body.error, 'UNTRUSTED_ORIGIN');
});

test('login, dashboard, decision, and run flow works', async () => {
  const wrong = await json('/api/auth/login', {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password: 'wrong' })
  });
  assert.equal(wrong.response.status, 401);

  const login = await json('/api/auth/login', {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password: 'integration-password' })
  });
  assert.equal(login.response.status, 200);
  assert.ok(login.body.token);
  const headers = { authorization: `Bearer ${login.body.token}`, 'content-type': 'application/json' };

  const dashboard = await json('/api/dashboard', { headers });
  assert.equal(dashboard.response.status, 200);
  assert.equal(dashboard.body.content[0].id, 'KR-TT-001');

  const mismatch = await json('/api/content/decision', {
    method: 'PATCH', headers, body: JSON.stringify({ row: 2, contentId: 'WRONG', eligibility: 'Review', status: 'Reviewed', notes: '' })
  });
  assert.equal(mismatch.response.status, 404);

  const patch = await json('/api/content/decision', {
    method: 'PATCH', headers, body: JSON.stringify({ row: 2, contentId: 'KR-TT-001', eligibility: 'Review', status: 'Reviewed', notes: '검증 완료' })
  });
  assert.equal(patch.response.status, 200);
  assert.equal(patch.body.updated, true);

  const run = await json('/api/runs', {
    method: 'POST', headers, body: JSON.stringify({ type: 'Collection', week: 'AUTO' })
  });
  assert.equal(run.response.status, 201);
  assert.equal(run.body.week, getIsoWeekKst());

  const updated = await json('/api/dashboard', { headers });
  assert.equal(updated.body.content.find((item) => item.id === 'KR-TT-001').notes, '검증 완료');
  assert.equal(updated.body.runs[0]['Run ID'], run.body.runId);
});

test('static traversal does not expose files', async () => {
  const response = await fetch(`${base}/..%2Fpackage.json`);
  assert.equal(response.status, 404);
});
