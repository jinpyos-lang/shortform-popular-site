import test from 'node:test';
import assert from 'node:assert/strict';
import { createSessionToken, verifySessionToken, verifyPassword, readSessionToken } from '../src/auth.mjs';
import { createOAuthState, verifyOAuthState, buildNotionAuthorizationUrl, authorizeNotionIdentity } from '../src/notion-oauth.mjs';
import { getIsoWeekKst, weekWindowKst, formatKstDateTime } from '../src/time.mjs';
import { validateRuntimeConfig } from '../src/config.mjs';
import { mockDashboard, normalizeDashboard, sheetColumnName } from '../src/domain.mjs';
import { patchContentDecision } from '../src/pipeline.mjs';

test('session tokens are signed and reject wrong secrets', () => {
  const token = createSessionToken('x'.repeat(32));
  assert.equal(verifySessionToken(token, 'x'.repeat(32)), true);
  assert.equal(verifySessionToken(token, 'y'.repeat(32)), false);
  assert.equal(verifyPassword('secret', 'secret'), true);
  assert.equal(verifyPassword('secret', 'other'), false);
});

test('KST ISO week and window are correct around Monday boundary', () => {
  const sundayUtc = new Date('2026-07-26T14:59:59Z'); // Sunday 23:59:59 KST
  const mondayUtc = new Date('2026-07-26T15:00:00Z'); // Monday 00:00 KST
  assert.equal(getIsoWeekKst(sundayUtc), '2026-W30');
  assert.equal(getIsoWeekKst(mondayUtc), '2026-W31');
  const window = weekWindowKst('2026-W31');
  assert.equal(window.startUtc, '2026-07-26T15:00:00.000Z');
  assert.equal(window.endUtc, '2026-08-02T15:00:00.000Z');
  assert.equal(formatKstDateTime(new Date(window.startUtc)), '2026-07-27 00:00:00');
});

test('runtime config blocks insecure production defaults', () => {
  const result = validateRuntimeConfig({
    NODE_ENV: 'production', DATA_MODE: 'mock', ADMIN_PASSWORD: 'change-this-password', AUTH_SECRET: 'short', MOCK_PUBLIC_PREVIEW: 'true'
  });
  assert.ok(result.errors.length >= 3);
});

test('mock dashboard and sheet helpers normalize values', () => {
  const mock = mockDashboard();
  assert.equal(mock.scope.market, '대한민국');
  assert.equal(sheetColumnName(35), 'AI');
  assert.equal(sheetColumnName(36), 'AJ');
  const normalized = normalizeDashboard({
    Dashboard: Array.from({ length: 22 }, () => []),
    Raw_Content: [[
      'Content ID','Week','Platform','Rank Candidate','URL','Creator','Posted At (KST)','Collected At (KST)','Hours Since Post','Duration Sec','Followers','Views','Likes','Comments','Shares','Saves','Title/Caption','Hashtags','Audio','Category','Views/Hour','Engagement Rate','Share+Save Rate','Follower Efficiency','View Score','Velocity Score','Engagement Score','Share+Save Score','Follower Eff. Score','Total Score','Analysis Status','Notes','Source/Collector','Korean Relevance Score','Eligibility','Thumbnail URL'
    ], ['X','2026-W31','TikTok','','https://example.com','creator','','',1,20,100,1000,50,10,5,2,'title','','','Entertainment',1000,'6.7%','','','','','','','',88,'Reviewed','','test',100,'Eligible','https://img.example/thumb.jpg']],
    Weekly_Ranking: [], Pattern_Learning: [], Run_Log: [], Settings: []
  });
  assert.equal(normalized.content[0].engagementRate, 0.067);
  assert.equal(normalized.content[0].totalScore, 88);
  assert.equal(normalized.content[0].thumbnailUrl, 'https://img.example/thumb.jpg');
});

test('content patch validation rejects invalid values before external calls', async () => {
  await assert.rejects(() => patchContentDecision({}, { row: 2, contentId: 'X', eligibility: 'Maybe', status: 'Reviewed' }), /Invalid eligibility/);
  await assert.rejects(() => patchContentDecision({}, { row: 2, contentId: 'X', eligibility: 'Review', status: 'Unknown' }), /Invalid analysis status/);
});


test('Notion OAuth state and account allow-list are validated', () => {
  const secret = 'o'.repeat(48);
  const state = createOAuthState(secret, '/rankings');
  assert.equal(verifyOAuthState(state, secret).returnTo, '/rankings');
  assert.equal(verifyOAuthState(state, 'wrong'), null);
  const config = {
    enabled: true,
    clientId: 'client',
    redirectUri: 'https://example.com/api/auth/notion/callback',
    authorizationUrl: 'https://api.notion.com/v1/oauth/authorize',
    allowedWorkspaceIds: ['workspace-1'],
    allowedUserIds: [],
    allowedEmails: ['owner@example.com']
  };
  const authUrl = buildNotionAuthorizationUrl(config, state);
  assert.match(authUrl, /owner=user/);
  const identity = authorizeNotionIdentity(config, {
    workspace_id: 'workspace-1', workspace_name: 'Mobius', workspace_icon: 'M',
    owner: { type: 'user', user: { id: 'user-1', name: 'Owner', avatar_url: 'https://img.example/avatar.png', person: { email: 'owner@example.com' } } }
  });
  assert.equal(identity.provider, 'notion');
  const token = createSessionToken(secret, identity);
  assert.equal(readSessionToken(token, secret).workspaceName, 'Mobius');
});
