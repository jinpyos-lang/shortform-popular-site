import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';

const root = new URL('..', import.meta.url);

async function text(name) {
  return fs.readFile(new URL(name, root), 'utf8');
}

test('every JavaScript element id exists in the HTML document', async () => {
  const [html, script] = await Promise.all([text('public/index.html'), text('public/app.js')]);
  const referencedIds = [...script.matchAll(/\$\('([^']+)'\)/g)].map((match) => match[1]);
  const htmlIds = [...html.matchAll(/id="([^"]+)"/g)].map((match) => match[1]);
  const missing = [...new Set(referencedIds)].filter((id) => !htmlIds.includes(id));
  const duplicates = htmlIds.filter((id, index) => htmlIds.indexOf(id) !== index);
  assert.deepEqual(missing, []);
  assert.deepEqual([...new Set(duplicates)], []);
});

test('navigation, sections, and friendly labels use the same contract', async () => {
  const [html, script, rawConfig] = await Promise.all([text('public/index.html'), text('public/app.js'), text('public/ui-config.json')]);
  const config = JSON.parse(rawConfig);
  for (const section of Object.keys(config.pages)) {
    assert.match(html, new RegExp(`data-section="${section}"`));
    assert.match(html, new RegExp(`id="${section}"`));
  }
  assert.equal(config.eligibility.Eligible.label, '추천');
  assert.equal(config.runStatus.Succeeded, '정상 완료');
  assert.ok(config.pipeline.length >= 8);
  assert.match(script, /video-thumbnail/);
  assert.match(html, /notionLoginBtn/);
});
