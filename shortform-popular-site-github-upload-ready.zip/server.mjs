import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { createSessionCookie, clearSessionCookie, createSessionToken, verifyPassword, getSession } from './src/auth.mjs';
import { googleConfigFromEnv, readDashboard, verifySheetsConnection } from './src/google-sheets.mjs';
import { notionConfigFromEnv, syncContentDecision, verifyNotionConnection } from './src/notion.mjs';
import { normalizeDashboard, mockDashboard } from './src/domain.mjs';
import { validateRuntimeConfig } from './src/config.mjs';
import { executeCollectionRun, patchContentDecision } from './src/pipeline.mjs';
import { providerConfigFromEnv } from './src/providers.mjs';
import { getIsoWeekKst } from './src/time.mjs';
import { notionOAuthConfigFromEnv, createOAuthState, verifyOAuthState, buildNotionAuthorizationUrl, exchangeNotionCode, authorizeNotionIdentity } from './src/notion-oauth.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(__dirname, 'public');
const env = process.env;
const APP_VERSION = '1.3.0';
const PORT = Number(env.PORT || 3000);
const DATA_MODE = env.DATA_MODE || 'mock';
const googleConfig = googleConfigFromEnv(env);
const notionConfig = notionConfigFromEnv(env);
const providerConfig = providerConfigFromEnv(env);
const notionOAuthConfig = notionOAuthConfigFromEnv(env);
const PASSWORD_LOGIN_ENABLED = env.PASSWORD_LOGIN_ENABLED !== 'false';
const runtime = validateRuntimeConfig(env);
const loginAttempts = new Map();
const mockState = mockDashboard();
let activeRunPromise = null;

for (const warning of runtime.warnings) console.warn(`[config warning] ${warning}`);
if (runtime.errors.length) {
  for (const error of runtime.errors) console.error(`[config error] ${error}`);
  process.exit(1);
}
if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) {
  console.error('[config error] PORT must be an integer from 1 to 65535.');
  process.exit(1);
}

function securityHeaders() {
  return {
    'content-security-policy': "default-src 'self'; connect-src 'self'; img-src 'self' data: https:; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors https://*.notion.com https://*.notion.so https://*.notion.site",
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'strict-origin-when-cross-origin',
    'permissions-policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'cross-origin-resource-policy': 'same-origin'
  };
}

function json(res, status, body, headers = {}) {
  res.writeHead(status, {
    ...securityHeaders(),
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    ...headers
  });
  res.end(JSON.stringify(body));
}

function redirect(res, location, headers = {}) {
  res.writeHead(302, {
    ...securityHeaders(),
    location,
    'cache-control': 'no-store',
    ...headers
  });
  res.end();
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 1_000_000) {
      const error = new Error('Request body too large.');
      error.statusCode = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    const error = new Error('Request body must be valid JSON.');
    error.statusCode = 400;
    throw error;
  }
}

function requestSession(req) {
  if (DATA_MODE === 'mock' && env.MOCK_PUBLIC_PREVIEW === 'true') {
    return { provider: 'preview', name: '미리보기 사용자', workspaceName: '체험 공간' };
  }
  return getSession(req, env.AUTH_SECRET);
}

function requestIsAuthenticated(req) {
  return Boolean(requestSession(req));
}

function requireAuth(req, res) {
  if (requestIsAuthenticated(req)) return true;
  json(res, 401, { error: 'UNAUTHORIZED' });
  return false;
}

function effectiveHost(req) {
  return String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
}

function trustedMutationOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
    const parsed = new URL(origin);
    if (parsed.host === effectiveHost(req)) return true;
    if (env.APP_BASE_URL && parsed.origin === new URL(env.APP_BASE_URL).origin) return true;
    return false;
  } catch {
    return false;
  }
}

function requireTrustedOrigin(req, res) {
  if (trustedMutationOrigin(req)) return true;
  json(res, 403, { error: 'UNTRUSTED_ORIGIN' });
  return false;
}

function clientKey(req) {
  return String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').split(',')[0].trim();
}

function canAttemptLogin(req) {
  const key = clientKey(req);
  const now = Date.now();
  const record = loginAttempts.get(key) || { count: 0, resetAt: now + 10 * 60_000 };
  if (record.resetAt <= now) {
    loginAttempts.set(key, { count: 1, resetAt: now + 10 * 60_000 });
    return true;
  }
  record.count += 1;
  loginAttempts.set(key, record);
  return record.count <= 20;
}

function clearLoginAttempts(req) {
  loginAttempts.delete(clientKey(req));
}

async function getDashboard() {
  if (DATA_MODE !== 'live') {
    mockState.generatedAt = new Date().toISOString();
    mockState.kpis = {
      ...mockState.kpis,
      rawItems: mockState.content.length,
      analyzedItems: mockState.content.filter((item) => ['Analyzed', 'Reviewed'].includes(item.status)).length,
      eligibleItems: mockState.content.filter((item) => item.eligibility === 'Eligible').length,
      reviewItems: mockState.content.filter((item) => item.eligibility === 'Review').length
    };
    return structuredClone(mockState);
  }
  return normalizeDashboard(await readDashboard(googleConfig), 'live');
}

async function patchContent(body) {
  const verdictMap = { Eligible: '지속', Review: '개선', Excluded: '폐기' };
  const reviewMap = { Pending: '미검토', Collected: '미검토', Analyzed: 'AI 분석 완료', Reviewed: '사람 검토 완료', Excluded: '제외' };

  if (DATA_MODE !== 'live') {
    const item = mockState.content.find((entry) => entry.row === Number(body.row) && (!body.contentId || entry.id === body.contentId));
    if (!item) throw Object.assign(new Error('선택한 영상을 찾을 수 없습니다. 최신 내용을 불러온 뒤 다시 시도해 주세요.'), { statusCode: 404, errorCode: 'CONTENT_NOT_FOUND' });
    if (!['Eligible', 'Review', 'Excluded'].includes(body.eligibility)) throw Object.assign(new Error('영상 처리 결과 값이 올바르지 않습니다.'), { statusCode: 400, errorCode: 'INVALID_ELIGIBILITY' });
    if (!['Pending', 'Collected', 'Analyzed', 'Reviewed', 'Excluded'].includes(body.status)) throw Object.assign(new Error('확인 진행 상태 값이 올바르지 않습니다.'), { statusCode: 400, errorCode: 'INVALID_ANALYSIS_STATUS' });
    item.eligibility = body.eligibility;
    item.status = body.status;
    item.notes = String(body.notes || '').slice(0, 2000);
    return { updated: true, mode: 'mock', row: item.row, contentId: item.id, notion: { skipped: true, reason: 'mock mode' } };
  }

  const patched = await patchContentDecision(googleConfig, body);
  let notion = { skipped: true, reason: 'Notion token not configured' };
  if (patched.contentId && notionConfig.token) {
    try {
      notion = await syncContentDecision(notionConfig, patched.contentId, {
        reviewStatus: reviewMap[patched.status] || '미검토',
        verdict: verdictMap[patched.eligibility] || '개선',
        notes: patched.notes
      });
    } catch (error) {
      notion = { updated: false, error: error.message };
    }
  }
  return { updated: true, ...patched, notion };
}

async function createRun(body, requestedBy = 'UI') {
  const week = body.week && body.week !== 'AUTO' ? body.week : getIsoWeekKst();
  if (DATA_MODE !== 'live') {
    const runId = `RUN-${week.replace('-', '')}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
    const run = {
      'Run ID': runId,
      'Run Type': body.type || 'Collection',
      Week: week,
      Status: 'Partial',
      'Items Read': 0,
      'Items Accepted': 0,
      Errors: 0,
      Notes: 'Mock mode: provider collection and external writes were not executed.'
    };
    mockState.runs.unshift(run);
    return { runId, type: run['Run Type'], week, status: run.Status, note: run.Notes, mode: 'mock' };
  }
  if (activeRunPromise) {
    const error = new Error('A collection run is already in progress.');
    error.statusCode = 409;
    throw error;
  }
  activeRunPromise = executeCollectionRun({ googleConfig, providerConfig, requestedWeek: week, requestedBy });
  try {
    return await activeRunPromise;
  } finally {
    activeRunPromise = null;
  }
}

async function deepHealth() {
  if (DATA_MODE !== 'live') return { sheets: { ok: false, skipped: 'mock mode' }, notion: { ok: false, skipped: 'mock mode' } };
  const [sheets, notion] = await Promise.allSettled([
    verifySheetsConnection(googleConfig),
    verifyNotionConnection(notionConfig)
  ]);
  return {
    sheets: sheets.status === 'fulfilled' ? sheets.value : { ok: false, error: sheets.reason?.message || String(sheets.reason) },
    notion: notion.status === 'fulfilled' ? notion.value : { ok: false, error: notion.reason?.message || String(notion.reason) }
  };
}

async function serveStatic(req, res) {
  if (!['GET', 'HEAD'].includes(req.method)) return false;
  const url = new URL(req.url, 'http://localhost');
  const requestPath = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname).replace(/^\/+/, '');
  const filePath = path.resolve(publicDir, requestPath);
  if (filePath !== publicDir && !filePath.startsWith(`${publicDir}${path.sep}`)) return false;
  try {
    const data = await fs.readFile(filePath);
    const ext = path.extname(filePath);
    const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.json': 'application/json; charset=utf-8' };
    res.writeHead(200, {
      ...securityHeaders(),
      'content-type': types[ext] || 'application/octet-stream',
      'cache-control': ext === '.html' ? 'no-store' : 'public, max-age=3600',
      'content-length': data.length
    });
    if (req.method === 'HEAD') return res.end();
    res.end(data);
    return true;
  } catch {
    return false;
  }
}

const server = http.createServer(async (req, res) => {
  const requestId = crypto.randomUUID();
  res.setHeader('x-request-id', requestId);
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (url.pathname === '/api/health' && req.method === 'GET') {
      const body = {
        ok: true,
        service: 'content-intelligence-console',
        version: APP_VERSION,
        mode: DATA_MODE,
        notionConfigured: Boolean(notionConfig.token && notionConfig.contentDataSourceId),
        notionOAuthConfigured: notionOAuthConfig.enabled,
        passwordLoginEnabled: PASSWORD_LOGIN_ENABLED,
        sheetsConfigured: Boolean(googleConfig.email && googleConfig.privateKey && googleConfig.sheetId),
        providersConfigured: {
          youtube: Boolean(providerConfig.youtube.apiKey),
          tiktok: Boolean(providerConfig.tiktok.url),
          instagram: Boolean(providerConfig.instagram.url)
        },
        time: new Date().toISOString()
      };
      if (url.searchParams.get('deep') === '1') {
        if (!requireAuth(req, res)) return;
        body.connections = await deepHealth();
        body.ok = Object.values(body.connections).every((item) => item.ok || item.skipped);
      }
      return json(res, body.ok ? 200 : 503, body);
    }

    if (url.pathname === '/api/auth/config' && req.method === 'GET') {
      return json(res, 200, {
        notionOAuthEnabled: notionOAuthConfig.enabled,
        passwordLoginEnabled: PASSWORD_LOGIN_ENABLED,
        loginLabel: notionOAuthConfig.enabled ? 'Notion 계정으로 시작하기' : '관리 비밀번호로 시작하기'
      });
    }

    if (url.pathname === '/api/auth/session' && req.method === 'GET') {
      const session = requestSession(req);
      return json(res, 200, {
        authenticated: Boolean(session),
        user: session ? {
          provider: session.provider || 'password',
          name: session.name || '운영자',
          email: session.email || '',
          avatarUrl: session.avatarUrl || '',
          workspaceName: session.workspaceName || ''
        } : null
      });
    }

    if (url.pathname === '/api/auth/notion/start' && req.method === 'GET') {
      if (!notionOAuthConfig.enabled) return json(res, 503, { error: 'NOTION_OAUTH_NOT_CONFIGURED', message: 'Notion 계정 로그인이 아직 연결되지 않았습니다.' });
      const state = createOAuthState(env.AUTH_SECRET, url.searchParams.get('returnTo') || '/');
      return redirect(res, buildNotionAuthorizationUrl(notionOAuthConfig, state));
    }

    if (url.pathname === '/api/auth/notion/callback' && req.method === 'GET') {
      const oauthError = url.searchParams.get('error');
      if (oauthError) return redirect(res, `/?authError=${encodeURIComponent(oauthError)}`);
      const state = verifyOAuthState(url.searchParams.get('state'), env.AUTH_SECRET);
      if (!state) return redirect(res, '/?authError=invalid_state');
      const code = url.searchParams.get('code');
      if (!code) return redirect(res, '/?authError=missing_code');
      try {
        const tokenResponse = await exchangeNotionCode(notionOAuthConfig, code);
        const identity = authorizeNotionIdentity(notionOAuthConfig, tokenResponse);
        const token = createSessionToken(env.AUTH_SECRET, identity);
        return redirect(res, state.returnTo || '/', {
          'set-cookie': createSessionCookie(env.AUTH_SECRET, {
            secure: env.NODE_ENV === 'production',
            embedMode: env.EMBED_MODE === 'true',
            claims: identity
          }),
          'x-session-created': token ? '1' : '0'
        });
      } catch (error) {
        const codeValue = error.errorCode || 'notion_login_failed';
        return redirect(res, `/?authError=${encodeURIComponent(codeValue)}`);
      }
    }

    if (url.pathname === '/api/auth/login' && req.method === 'POST') {
      if (!PASSWORD_LOGIN_ENABLED) return json(res, 404, { error: 'PASSWORD_LOGIN_DISABLED' });
      if (!requireTrustedOrigin(req, res)) return;
      if (!canAttemptLogin(req)) return json(res, 429, { error: 'TOO_MANY_LOGIN_ATTEMPTS' }, { 'retry-after': '600' });
      const body = await readJson(req);
      if (!verifyPassword(body.password, env.ADMIN_PASSWORD)) return json(res, 401, { error: 'INVALID_PASSWORD' });
      clearLoginAttempts(req);
      const claims = { provider: 'password', name: '운영자' };
      const token = createSessionToken(env.AUTH_SECRET, claims);
      return json(res, 200, { ok: true, token, user: claims }, { 'set-cookie': createSessionCookie(env.AUTH_SECRET, { secure: env.NODE_ENV === 'production', embedMode: env.EMBED_MODE === 'true', claims }) });
    }

    if (url.pathname === '/api/auth/logout' && req.method === 'POST') {
      if (!requireTrustedOrigin(req, res)) return;
      return json(res, 200, { ok: true }, { 'set-cookie': clearSessionCookie({ secure: env.NODE_ENV === 'production', embedMode: env.EMBED_MODE === 'true' }) });
    }

    if (url.pathname === '/api/dashboard' && req.method === 'GET') {
      if (!requireAuth(req, res)) return;
      return json(res, 200, await getDashboard());
    }

    if (url.pathname === '/api/content/decision' && req.method === 'PATCH') {
      if (!requireTrustedOrigin(req, res) || !requireAuth(req, res)) return;
      return json(res, 200, await patchContent(await readJson(req)));
    }

    if (url.pathname === '/api/runs' && req.method === 'POST') {
      if (!requireTrustedOrigin(req, res) || !requireAuth(req, res)) return;
      return json(res, 201, await createRun(await readJson(req), 'UI'));
    }

    if (url.pathname === '/api/cron/weekly' && req.method === 'GET') {
      const bearer = req.headers.authorization || '';
      if (!env.CRON_SECRET || bearer !== `Bearer ${env.CRON_SECRET}`) return json(res, 401, { error: 'INVALID_CRON_SECRET' });
      return json(res, 200, await createRun({ type: 'Collection', week: url.searchParams.get('week') || 'AUTO' }, 'Cron'));
    }

    if (url.pathname.startsWith('/api/')) return json(res, 404, { error: 'NOT_FOUND' });
    if (await serveStatic(req, res)) return;
    res.writeHead(404, { ...securityHeaders(), 'content-type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  } catch (error) {
    const status = Number(error.statusCode) || 500;
    if (status >= 500) console.error(`[${requestId}]`, error);
    else if (env.NODE_ENV !== 'test') console.warn(`[${requestId}] ${status} ${error.errorCode || 'REQUEST_ERROR'}: ${error.message}`);
    json(res, status, {
      error: error.errorCode || (status >= 500 ? 'INTERNAL_ERROR' : status === 404 ? 'NOT_FOUND' : 'BAD_REQUEST'),
      message: env.NODE_ENV === 'production' && status >= 500 ? '요청을 완료하지 못했습니다.' : error.message,
      requestId
    });
  }
});

server.requestTimeout = 120_000;
server.headersTimeout = 30_000;
server.keepAliveTimeout = 5_000;

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Shortform Popular Site v${APP_VERSION} running at http://0.0.0.0:${PORT} (${DATA_MODE})`);
});

function shutdown(signal) {
  console.log(`${signal} received; closing HTTP server.`);
  server.close((error) => process.exit(error ? 1 : 0));
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
