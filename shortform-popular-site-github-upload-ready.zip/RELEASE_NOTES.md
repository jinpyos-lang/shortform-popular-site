# Release 1.3.0 — Notion 계정 로그인과 영상 썸네일

릴리스 날짜: 2026-07-26

## 추가

- Notion OAuth 로그인 시작·콜백 API
- OAuth state 서명과 만료 검증
- 허용 워크스페이스·사용자·이메일 검사
- 로그인 사용자 프로필 UI
- 비밀번호 로그인 선택적 비활성화
- `Thumbnail URL` 데이터 필드
- YouTube 실제 썸네일 자동 연결
- TikTok·Instagram Webhook 썸네일 필드 정규화
- 영상 확인·상위 후보·플랫폼 순위 썸네일
- 이미지 오류 시 플랫폼별 대체 썸네일

## 데이터 변경

Google Sheets `Raw_Content`에 `AJ: Thumbnail URL` 열을 추가했습니다. 기존 A:AI 열과 판정 저장 위치는 변경하지 않았습니다.

## 검증

- 정적 문법 검사 통과
- 자동 테스트 15개 통과
- Live 수집 파이프라인 Mock API 통합 테스트 통과
- OAuth state·허용 목록·세션 claim 테스트 통과
- npm audit 취약점 0개
