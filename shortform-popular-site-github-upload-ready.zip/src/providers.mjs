const YOUTUBE_BASE = 'https://www.googleapis.com/youtube/v3';

function splitCsv(value = '') {
  return String(value).split(',').map((item) => item.trim()).filter(Boolean);
}

function parseDuration(value = '') {
  const match = /^P(?:(\d+)D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(value);
  if (!match) return 0;
  return Number(match[1] || 0) * 86400 + Number(match[2] || 0) * 3600 + Number(match[3] || 0) * 60 + Number(match[4] || 0);
}

function number(value) {
  const parsed = Number(value || 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function koreanRelevance(text = '') {
  const hangul = (String(text).match(/[가-힣]/g) || []).length;
  const total = Math.max(String(text).replace(/\s/g, '').length, 1);
  return Math.min(100, Math.round(55 + (hangul / total) * 70));
}

async function fetchJson(url, init = {}, timeoutMs = 20_000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const text = await response.text();
    const body = text ? JSON.parse(text) : {};
    if (!response.ok) throw new Error(body?.error?.message || body?.message || `HTTP ${response.status}`);
    return body;
  } finally {
    clearTimeout(timeout);
  }
}

async function youtubeRequest(path, params, key) {
  const query = new URLSearchParams({ ...params, key });
  return fetchJson(`${YOUTUBE_BASE}/${path}?${query.toString()}`);
}

export async function collectYouTube(config, window) {
  if (!config.apiKey) return { provider: 'YouTube Shorts', skipped: true, reason: 'YOUTUBE_API_KEY not configured', items: [] };
  const queries = config.queries.length ? config.queries : ['쇼츠', 'shorts', '챌린지'];
  const videoIds = new Set();

  for (const query of queries.slice(0, config.maxQueries)) {
    const result = await youtubeRequest('search', {
      part: 'snippet',
      type: 'video',
      order: 'viewCount',
      regionCode: 'KR',
      relevanceLanguage: 'ko',
      videoDuration: 'short',
      publishedAfter: window.startUtc,
      publishedBefore: window.endUtc,
      maxResults: String(config.maxPerQuery),
      q: query
    }, config.apiKey);
    for (const item of result.items || []) if (item.id?.videoId) videoIds.add(item.id.videoId);
  }

  const ids = [...videoIds];
  if (!ids.length) return { provider: 'YouTube Shorts', skipped: false, items: [] };
  const detailItems = [];
  for (let index = 0; index < ids.length; index += 50) {
    const details = await youtubeRequest('videos', { part: 'snippet,statistics,contentDetails', id: ids.slice(index, index + 50).join(',') }, config.apiKey);
    detailItems.push(...(details.items || []));
  }
  const channelIds = [...new Set(detailItems.map((item) => item.snippet?.channelId).filter(Boolean))];
  const channelItems = [];
  for (let index = 0; index < channelIds.length; index += 50) {
    const channels = await youtubeRequest('channels', { part: 'statistics', id: channelIds.slice(index, index + 50).join(',') }, config.apiKey);
    channelItems.push(...(channels.items || []));
  }
  const followers = new Map(channelItems.map((item) => [item.id, number(item.statistics?.subscriberCount)]));

  const items = detailItems.map((item) => {
    const durationSec = parseDuration(item.contentDetails?.duration);
    const text = `${item.snippet?.title || ''} ${item.snippet?.description || ''}`;
    return {
      providerId: item.id,
      platform: 'YouTube Shorts',
      url: `https://www.youtube.com/shorts/${item.id}`,
      creator: item.snippet?.channelTitle || '',
      postedAt: item.snippet?.publishedAt || '',
      durationSec,
      followers: followers.get(item.snippet?.channelId) || 0,
      views: number(item.statistics?.viewCount),
      likes: number(item.statistics?.likeCount),
      comments: number(item.statistics?.commentCount),
      shares: 0,
      saves: 0,
      title: item.snippet?.title || '',
      hashtags: (text.match(/#[\p{L}\p{N}_]+/gu) || []).join(' '),
      audio: '',
      category: 'Unclassified',
      source: 'YouTube Data API',
      thumbnailUrl: item.snippet?.thumbnails?.maxres?.url || item.snippet?.thumbnails?.standard?.url || item.snippet?.thumbnails?.high?.url || item.snippet?.thumbnails?.medium?.url || item.snippet?.thumbnails?.default?.url || `https://i.ytimg.com/vi/${item.id}/hqdefault.jpg`,
      relevance: koreanRelevance(text),
      eligibility: durationSec > 0 && durationSec <= config.maxDurationSec ? 'Review' : 'Excluded'
    };
  }).filter((item) => item.durationSec > 0 && item.durationSec <= config.maxDurationSec);

  return { provider: 'YouTube Shorts', skipped: false, items };
}

function normalizeWebhookItem(provider, item = {}) {
  const platform = provider === 'TikTok' ? 'TikTok' : 'Instagram Reels';
  const title = item.title || item.caption || item.description || '';
  return {
    providerId: String(item.id || item.videoId || item.mediaId || item.url || ''),
    platform,
    url: item.url || item.permalink || '',
    creator: item.creator || item.username || item.author || '',
    postedAt: item.postedAt || item.publishedAt || item.timestamp || '',
    durationSec: number(item.durationSec || item.duration),
    followers: number(item.followers || item.followerCount),
    views: number(item.views || item.viewCount || item.plays),
    likes: number(item.likes || item.likeCount),
    comments: number(item.comments || item.commentCount),
    shares: number(item.shares || item.shareCount),
    saves: number(item.saves || item.saveCount),
    title,
    hashtags: Array.isArray(item.hashtags) ? item.hashtags.join(' ') : (item.hashtags || ''),
    audio: item.audio || item.sound || '',
    category: item.category || 'Unclassified',
    source: item.source || `${provider} webhook`,
    thumbnailUrl: item.thumbnailUrl || item.thumbnail_url || item.coverUrl || item.cover_url || item.cover || item.thumbnail || '',
    relevance: number(item.relevance || item.koreanRelevanceScore || koreanRelevance(title)),
    eligibility: item.eligibility || 'Review'
  };
}

export async function collectWebhook(provider, config, window) {
  if (!config.url) return { provider, skipped: true, reason: `${provider} webhook not configured`, items: [] };
  const body = await fetchJson(config.url, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      ...(config.secret ? { authorization: `Bearer ${config.secret}` } : {})
    },
    body: JSON.stringify({ market: 'KR', language: 'ko', week: window.week, startUtc: window.startUtc, endUtc: window.endUtc })
  }, config.timeoutMs);
  const rawItems = Array.isArray(body) ? body : (body.items || []);
  return { provider, skipped: false, items: rawItems.map((item) => normalizeWebhookItem(provider, item)) };
}

export function providerConfigFromEnv(env) {
  return {
    youtube: {
      apiKey: env.YOUTUBE_API_KEY || '',
      queries: splitCsv(env.YOUTUBE_SEARCH_QUERIES),
      maxQueries: Math.min(Math.max(Number(env.YOUTUBE_MAX_QUERIES || 3), 1), 10),
      maxPerQuery: Math.min(Math.max(Number(env.YOUTUBE_MAX_PER_QUERY || 25), 1), 50),
      maxDurationSec: Math.min(Math.max(Number(env.SHORT_FORM_MAX_DURATION_SEC || 180), 15), 240)
    },
    tiktok: {
      url: env.TIKTOK_COLLECTION_WEBHOOK_URL || '',
      secret: env.TIKTOK_COLLECTION_WEBHOOK_SECRET || '',
      timeoutMs: Number(env.PROVIDER_TIMEOUT_MS || 30_000)
    },
    instagram: {
      url: env.INSTAGRAM_COLLECTION_WEBHOOK_URL || '',
      secret: env.INSTAGRAM_COLLECTION_WEBHOOK_SECRET || '',
      timeoutMs: Number(env.PROVIDER_TIMEOUT_MS || 30_000)
    }
  };
}
