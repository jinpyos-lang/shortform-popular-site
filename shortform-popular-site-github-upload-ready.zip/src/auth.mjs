import crypto from 'node:crypto';

const COOKIE_NAME = 'cic_session';
const SESSION_TTL_SECONDS = 60 * 60 * 12;

function b64url(input) {
  return Buffer.from(input).toString('base64url');
}

function sign(value, secret) {
  return crypto.createHmac('sha256', secret).update(value).digest('base64url');
}

function timingSafeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

function safeClaims(claims = {}) {
  return {
    provider: String(claims.provider || 'password').slice(0, 30),
    userId: String(claims.userId || '').slice(0, 200),
    name: String(claims.name || '').slice(0, 150),
    email: String(claims.email || '').slice(0, 320),
    avatarUrl: String(claims.avatarUrl || '').slice(0, 2000),
    workspaceId: String(claims.workspaceId || '').slice(0, 200),
    workspaceName: String(claims.workspaceName || '').slice(0, 200),
    workspaceIcon: String(claims.workspaceIcon || '').slice(0, 1000)
  };
}

export function createSessionToken(secret, claims = {}) {
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(JSON.stringify({ iat: now, exp: now + SESSION_TTL_SECONDS, ...safeClaims(claims) }));
  return `${payload}.${sign(payload, secret)}`;
}

export function readSessionToken(token, secret) {
  if (!token || !secret) return null;
  const [payload, signature] = String(token).split('.');
  if (!payload || !signature || !timingSafeEqual(signature, sign(payload, secret))) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return parsed.exp > Math.floor(Date.now() / 1000) ? parsed : null;
  } catch {
    return null;
  }
}

export function verifySessionToken(token, secret) {
  return Boolean(readSessionToken(token, secret));
}

export function createSessionCookie(secret, { secure = false, embedMode = false, claims = {} } = {}) {
  const attributes = [
    `${COOKIE_NAME}=${createSessionToken(secret, claims)}`,
    'HttpOnly',
    `SameSite=${embedMode ? 'None' : 'Lax'}`,
    'Path=/',
    `Max-Age=${SESSION_TTL_SECONDS}`
  ];
  if (secure || embedMode) attributes.push('Secure');
  return attributes.join('; ');
}

export function clearSessionCookie({ secure = false, embedMode = false } = {}) {
  const attributes = [`${COOKIE_NAME}=`, 'HttpOnly', `SameSite=${embedMode ? 'None' : 'Lax'}`, 'Path=/', 'Max-Age=0'];
  if (secure || embedMode) attributes.push('Secure');
  return attributes.join('; ');
}

export function verifyPassword(candidate, expected) {
  return Boolean(candidate && expected && timingSafeEqual(candidate, expected));
}

export function getRequestToken(req) {
  const authorization = req.headers.authorization || '';
  if (authorization.startsWith('Bearer ')) return authorization.slice(7);
  const cookie = req.headers.cookie || '';
  const match = cookie.match(new RegExp(`(?:^|;\\s*)${COOKIE_NAME}=([^;]+)`));
  return match?.[1] || '';
}

export function getSession(req, secret) {
  return readSessionToken(getRequestToken(req), secret);
}

export function isAuthenticated(req, secret) {
  return Boolean(getSession(req, secret));
}
