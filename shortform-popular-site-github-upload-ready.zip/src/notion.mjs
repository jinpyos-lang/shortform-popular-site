const BASE_URL = 'https://api.notion.com/v1';

function headers(config) {
  return {
    authorization: `Bearer ${config.token}`,
    'Notion-Version': config.version || '2026-03-11',
    'content-type': 'application/json'
  };
}

async function notionFetch(config, path, init = {}) {
  if (!config.token) throw new Error('NOTION_API_TOKEN is missing.');
  const response = await fetch(`${BASE_URL}${path}`, {
    ...init,
    headers: { ...headers(config), ...(init.headers || {}) }
  });
  const text = await response.text();
  let body = {};
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  if (!response.ok) throw new Error(body.message || `Notion API ${response.status}`);
  return body;
}

export async function queryDataSource(config, dataSourceId, filter, pageSize = 100) {
  if (!dataSourceId) throw new Error('Notion data source ID is missing.');
  return notionFetch(config, `/data_sources/${dataSourceId}/query`, {
    method: 'POST',
    body: JSON.stringify({ filter, page_size: pageSize })
  });
}

export async function retrieveDataSource(config, dataSourceId) {
  if (!dataSourceId) throw new Error('Notion data source ID is missing.');
  return notionFetch(config, `/data_sources/${dataSourceId}`);
}

export async function updatePage(config, pageId, properties) {
  return notionFetch(config, `/pages/${pageId}`, {
    method: 'PATCH',
    body: JSON.stringify({ properties })
  });
}

function richText(value) {
  const content = String(value ?? '').slice(0, 2000);
  return { rich_text: content ? [{ type: 'text', text: { content } }] : [] };
}

export async function syncContentDecision(config, contentId, decision) {
  if (!config.contentDataSourceId) return { skipped: true, reason: 'content data source not configured' };
  const result = await queryDataSource(config, config.contentDataSourceId, {
    property: 'Content ID',
    rich_text: { equals: contentId }
  }, 10);
  const page = result.results?.[0];
  if (!page) return { skipped: true, reason: 'matching Notion content row not found' };

  const properties = {};
  if (decision.reviewStatus) properties['검토 상태'] = { select: { name: decision.reviewStatus } };
  if (decision.verdict) properties['판정'] = { select: { name: decision.verdict } };
  if (decision.notes !== undefined) properties['위험·한계'] = richText(decision.notes);
  if (Object.keys(properties).length === 0) return { skipped: true, reason: 'no mapped properties' };
  await updatePage(config, page.id, properties);
  return { updated: true, pageId: page.id, url: page.url };
}

export async function verifyNotionConnection(config) {
  const source = await retrieveDataSource(config, config.contentDataSourceId);
  return { ok: true, id: source.id, title: source.title?.[0]?.plain_text || '' };
}

export function notionConfigFromEnv(env) {
  return {
    token: env.NOTION_API_TOKEN,
    version: env.NOTION_VERSION || '2026-03-11',
    hubPageId: env.NOTION_HUB_PAGE_ID,
    weeklyReportDataSourceId: env.NOTION_WEEKLY_REPORT_DATA_SOURCE_ID,
    contentDataSourceId: env.NOTION_CONTENT_DATA_SOURCE_ID,
    patternDataSourceId: env.NOTION_PATTERN_DATA_SOURCE_ID,
    changelogDataSourceId: env.NOTION_CHANGELOG_DATA_SOURCE_ID,
    taskDataSourceId: env.NOTION_TASK_DATA_SOURCE_ID
  };
}
