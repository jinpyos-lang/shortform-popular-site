import crypto from 'node:crypto';

const AUTHORIZE_URL = 'https://api.notion.com/v1/oauth/authorize';
const TOKEN_URL = 'https://api.notion.com/v1/oauth/token';
const STATE_TTL_SECONDS = 10 * 60;

function b64url(value) {
  return Buffer.from(typeof value === 'string' ? value : JSON.stringify(value)).toString('base64url');
}

function sign(value, secret) {
  return crypto.createHmac('sha256', secret).update(value).digest('base64url');
}

function equal(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

function splitCsv(value = '') {
  return String(value).split(',').map((item) => item.trim()).filter(Boolean);
}

export function notionOAuthConfigFromEnv(env) {
  const redirectUri = env.NOTION_OAUTH_REDIRECT_URI || (env.APP_BASE_URL ? `${String(env.APP_BASE_URL).replace(/\/$/, '')}/api/auth/notion/callback` : '');
  const enabled = env.NOTION_OAUTH_ENABLED === 'true' || Boolean(env.NOTION_OAUTH_CLIENT_ID && env.NOTION_OAUTH_CLIENT_SECRET && redirectUri);
  return {
    enabled,
    clientId: env.NOTION_OAUTH_CLIENT_ID || '',
    clientSecret: env.NOTION_OAUTH_CLIENT_SECRET || '',
    redirectUri,
    authorizationUrl: env.NOTION_OAUTH_AUTH_URL || AUTHORIZE_URL,
    allowedWorkspaceIds: splitCsv(env.NOTION_ALLOWED_WORKSPACE_IDS),
    allowedUserIds: splitCsv(env.NOTION_ALLOWED_USER_IDS),
    allowedEmails: splitCsv(env.NOTION_ALLOWED_EMAILS).map((value) => value.toLowerCase())
  };
}

export function createOAuthState(secret, returnTo = '/') {
  const now = Math.floor(Date.now() / 1000);
  const safeReturnTo = String(returnTo || '/').startsWith('/') && !String(returnTo).startsWith('//') ? String(returnTo) : '/';
  const payload = b64url({ iat: now, exp: now + STATE_TTL_SECONDS, nonce: crypto.randomBytes(16).toString('hex'), returnTo: safeReturnTo });
  return `${payload}.${sign(payload, secret)}`;
}

export function verifyOAuthState(state, secret) {
  const [payload, signature] = String(state || '').split('.');
  if (!payload || !signature || !secret || !equal(signature, sign(payload, secret))) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!parsed.exp || parsed.exp <= Math.floor(Date.now() / 1000)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function buildNotionAuthorizationUrl(config, state) {
  if (!config.enabled || !config.clientId || !config.redirectUri) throw new Error('Notion OAuth is not configured.');
  const url = new URL(config.authorizationUrl);
  url.searchParams.set('owner', 'user');
  url.searchParams.set('client_id', config.clientId);
  url.searchParams.set('redirect_uri', config.redirectUri);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('state', state);
  return url.href;
}

export async function exchangeNotionCode(config, code) {
  if (!config.clientId || !config.clientSecret || !config.redirectUri) throw new Error('Notion OAuth credentials are incomplete.');
  const authorization = Buffer.from(`${config.clientId}:${config.clientSecret}`).toString('base64');
  const response = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: {
      accept: 'application/json',
      authorization: `Basic ${authorization}`,
      'content-type': 'application/json'
    },
    body: JSON.stringify({ grant_type: 'authorization_code', code, redirect_uri: config.redirectUri })
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(body.error_description || body.error || body.message || `Notion OAuth token exchange failed (${response.status}).`);
    error.statusCode = 401;
    error.errorCode = 'NOTION_OAUTH_EXCHANGE_FAILED';
    throw error;
  }
  return body;
}

export function authorizeNotionIdentity(config, tokenResponse) {
  const owner = tokenResponse?.owner?.type === 'user' ? tokenResponse.owner.user : null;
  const workspaceId = String(tokenResponse?.workspace_id || '');
  const userId = String(owner?.id || '');
  const email = String(owner?.person?.email || '').toLowerCase();

  if (!owner || !workspaceId || !userId) {
    const error = new Error('Notion user identity was not included in the authorization response.');
    error.statusCode = 403;
    error.errorCode = 'NOTION_IDENTITY_MISSING';
    throw error;
  }
  if (config.allowedWorkspaceIds.length && !config.allowedWorkspaceIds.includes(workspaceId)) {
    const error = new Error('This Notion workspace is not allowed to use the site.');
    error.statusCode = 403;
    error.errorCode = 'NOTION_WORKSPACE_NOT_ALLOWED';
    throw error;
  }
  if ((config.allowedUserIds.length || config.allowedEmails.length)
      && !config.allowedUserIds.includes(userId)
      && !(email && config.allowedEmails.includes(email))) {
    const error = new Error('This Notion account is not allowed to use the site.');
    error.statusCode = 403;
    error.errorCode = 'NOTION_USER_NOT_ALLOWED';
    throw error;
  }

  return {
    provider: 'notion',
    userId,
    name: String(owner.name || 'Notion 사용자').slice(0, 150),
    email: email.slice(0, 320),
    avatarUrl: String(owner.avatar_url || '').slice(0, 2000),
    workspaceId,
    workspaceName: String(tokenResponse.workspace_name || 'Notion 워크스페이스').slice(0, 200),
    workspaceIcon: String(tokenResponse.workspace_icon || '').slice(0, 1000)
  };
}
