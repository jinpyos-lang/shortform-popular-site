import crypto from 'node:crypto';
import { appendValues, batchGetValues, batchUpdateValues, getValues, parseUpdatedStartRow, updateValues } from './google-sheets.mjs';
import { collectYouTube, collectWebhook } from './providers.mjs';
import { formatKstDateTime, getIsoWeekKst, weekWindowKst } from './time.mjs';

const MAX_RAW_ROWS = 500;

function number(value) {
  const parsed = Number(value || 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function hoursSince(postedAt) {
  const posted = new Date(postedAt);
  if (Number.isNaN(posted.getTime())) return 0;
  return Math.max(0, (Date.now() - posted.getTime()) / 3600000);
}

function safeText(value, max = 5000) {
  return String(value ?? '').slice(0, max);
}

function makeContentId(item) {
  const prefix = item.platform === 'TikTok' ? 'TT' : item.platform === 'Instagram Reels' ? 'IG' : 'YT';
  const sourceId = safeText(item.providerId || item.url || crypto.randomUUID(), 120);
  const digest = crypto.createHash('sha256').update(sourceId).digest('hex').slice(0, 12).toUpperCase();
  return `KR-${prefix}-${digest}`;
}

function formulaRow(row) {
  return [
    `=IF(A${row}="","",IFERROR(L${row}/I${row},0))`,
    `=IF(A${row}="","",IFERROR((M${row}+N${row}+O${row}+P${row})/L${row},0))`,
    `=IF(A${row}="","",IFERROR((O${row}+P${row})/L${row},0))`,
    `=IF(A${row}="","",IFERROR(L${row}/K${row},0))`,
    `=IF(A${row}="","",MIN(IFERROR(L${row}/Settings!$B$7,0),1)*100)`,
    `=IF(A${row}="","",MIN(IFERROR(U${row}/Settings!$B$8,0),1)*100)`,
    `=IF(A${row}="","",MIN(IFERROR(V${row}/Settings!$B$9,0),1)*100)`,
    `=IF(A${row}="","",MIN(IFERROR(W${row}/Settings!$B$10,0),1)*100)`,
    `=IF(A${row}="","",MIN(IFERROR(X${row}/Settings!$B$11,0),1)*100)`,
    `=IF(A${row}="","",Y${row}*Settings!$B$2+Z${row}*Settings!$B$3+AA${row}*Settings!$B$4+AB${row}*Settings!$B$5+AC${row}*Settings!$B$6)`
  ];
}

function rowForItem(item, row, week) {
  const postedDate = item.postedAt ? new Date(item.postedAt) : null;
  const postedAt = postedDate && !Number.isNaN(postedDate.getTime()) ? formatKstDateTime(postedDate) : '';
  const contentId = makeContentId(item);
  return [
    contentId,
    week,
    item.platform,
    '',
    safeText(item.url, 2000),
    safeText(item.creator, 300),
    postedAt,
    formatKstDateTime(),
    hoursSince(item.postedAt),
    number(item.durationSec),
    number(item.followers),
    number(item.views),
    number(item.likes),
    number(item.comments),
    number(item.shares),
    number(item.saves),
    safeText(item.title, 5000),
    safeText(item.hashtags, 2000),
    safeText(item.audio, 500),
    safeText(item.category || 'Unclassified', 200),
    ...formulaRow(row),
    'Collected',
    '',
    safeText(item.source, 500),
    Math.min(Math.max(number(item.relevance), 0), 100),
    ['Eligible', 'Review', 'Excluded'].includes(item.eligibility) ? item.eligibility : 'Review',
    safeText(item.thumbnailUrl, 2000)
  ];
}

function deduplicate(items, existingIds, existingUrls) {
  const seenIds = new Set(existingIds);
  const seenUrls = new Set(existingUrls);
  const result = [];
  for (const item of items) {
    const id = makeContentId(item);
    const url = String(item.url || '');
    if (!url || seenIds.has(id) || seenUrls.has(url)) continue;
    seenIds.add(id);
    seenUrls.add(url);
    result.push(item);
  }
  return result;
}

function parseRunRow(updatedRange) {
  return parseUpdatedStartRow(updatedRange);
}

async function updateRunLog(config, row, values) {
  await updateValues(config, `Run_Log!D${row}:O${row}`, [values]);
}

export async function executeCollectionRun({ googleConfig, providerConfig, requestedWeek = 'AUTO', requestedBy = 'UI' }) {
  const week = !requestedWeek || requestedWeek === 'AUTO' ? getIsoWeekKst() : requestedWeek;
  const window = weekWindowKst(week);
  const runId = `RUN-${week.replace('-', '')}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
  const startedAt = formatKstDateTime();
  const append = await appendValues(googleConfig, 'Run_Log!A:O', [[
    runId, 'Collection', week, startedAt, '', 'Running', 0, 0, 0, 0,
    'v1.1-KR-ALL', 'v1.1', '', '', `Triggered by ${requestedBy}`
  ]]);
  const runRow = parseRunRow(append.updates?.updatedRange);
  if (!runRow) throw new Error('Could not determine the appended Run_Log row.');

  try {
    const providerResults = await Promise.allSettled([
      collectYouTube(providerConfig.youtube, window),
      collectWebhook('TikTok', providerConfig.tiktok, window),
      collectWebhook('Instagram', providerConfig.instagram, window)
    ]);

    const providerSummary = [];
    const collected = [];
    let errors = 0;
    for (const result of providerResults) {
      if (result.status === 'rejected') {
        errors += 1;
        providerSummary.push(`provider error: ${result.reason?.message || result.reason}`);
        continue;
      }
      providerSummary.push(`${result.value.provider}: ${result.value.skipped ? `skipped (${result.value.reason})` : `${result.value.items.length} items`}`);
      collected.push(...result.value.items);
    }

    const current = await batchGetValues(googleConfig, ['Raw_Content!A2:A500', 'Raw_Content!E2:E500']);
    const idRows = current.valueRanges?.[0]?.values || [];
    const urlRows = current.valueRanges?.[1]?.values || [];
    const existingIds = idRows.flat().filter(Boolean);
    const existingUrls = urlRows.flat().filter(Boolean);
    const uniqueItems = deduplicate(collected, existingIds, existingUrls);
    const lastUsedOffset = idRows.reduce((last, row, index) => row?.[0] ? index : last, -1);
    const startRow = lastUsedOffset + 3;
    const capacity = Math.max(0, MAX_RAW_ROWS - startRow + 1);
    const accepted = uniqueItems.slice(0, capacity);
    const excluded = Math.max(0, collected.length - accepted.length);

    if (accepted.length) {
      const rows = accepted.map((item, index) => rowForItem(item, startRow + index, week));
      await updateValues(googleConfig, `Raw_Content!A${startRow}:AJ${startRow + rows.length - 1}`, rows);
    }

    const configuredProviders = [providerConfig.youtube.apiKey, providerConfig.tiktok.url, providerConfig.instagram.url].filter(Boolean).length;
    const status = errors > 0 ? (accepted.length ? 'Partial' : 'Failed') : configuredProviders === 0 ? 'Partial' : 'Succeeded';
    const finishedAt = formatKstDateTime();
    const notes = [
      ...providerSummary,
      configuredProviders === 0 ? 'No collection provider credentials are configured.' : '',
      capacity < uniqueItems.length ? `Raw_Content capacity reached; ${uniqueItems.length - capacity} items were not written.` : ''
    ].filter(Boolean).join(' | ').slice(0, 5000);

    await updateRunLog(googleConfig, runRow, [
      startedAt, finishedAt, status, collected.length, accepted.length, excluded, errors,
      'v1.1-KR-ALL', 'v1.1', '', accepted.length ? `Raw_Content!A${startRow}:AJ${startRow + accepted.length - 1}` : '', notes
    ]);

    return {
      runId,
      runRow,
      week,
      status,
      itemsRead: collected.length,
      itemsAccepted: accepted.length,
      itemsExcluded: excluded,
      errors,
      notes,
      providers: providerSummary
    };
  } catch (error) {
    const notes = `Pipeline failure: ${error.message}`.slice(0, 5000);
    try {
      await updateRunLog(googleConfig, runRow, [
        startedAt, formatKstDateTime(), 'Failed', 0, 0, 0, 1,
        'v1.1-KR-ALL', 'v1.1', '', '', notes
      ]);
    } catch (logError) {
      error.message = `${error.message}; failed to update Run_Log: ${logError.message}`;
    }
    throw error;
  }
}

export async function verifyContentRow(config, row, contentId) {
  if (!Number.isInteger(row) || row < 2 || row > MAX_RAW_ROWS) throw new Error('Invalid sheet row.');
  const result = await getValues(config, `Raw_Content!A${row}:AJ${row}`);
  const values = result.values?.[0] || [];
  if (!values[0]) throw new Error('The selected Raw_Content row is empty.');
  if (contentId && values[0] !== contentId) throw new Error('Content ID does not match the selected sheet row. Refresh and try again.');
  return values;
}

export async function patchContentDecision(config, body) {
  const row = Number(body.row);
  const contentId = safeText(body.contentId, 200);
  const eligibility = body.eligibility;
  const status = body.status;
  const notes = safeText(body.notes, 2000);
  const allowedEligibility = new Set(['Eligible', 'Review', 'Excluded']);
  const allowedStatus = new Set(['Pending', 'Collected', 'Analyzed', 'Reviewed', 'Excluded']);
  if (!allowedEligibility.has(eligibility)) throw new Error('Invalid eligibility value.');
  if (!allowedStatus.has(status)) throw new Error('Invalid analysis status value.');
  await verifyContentRow(config, row, contentId);
  await batchUpdateValues(config, [
    { range: `Raw_Content!AE${row}`, values: [[status]] },
    { range: `Raw_Content!AF${row}`, values: [[notes]] },
    { range: `Raw_Content!AI${row}`, values: [[eligibility]] }
  ]);
  return { row, contentId, eligibility, status, notes };
}
