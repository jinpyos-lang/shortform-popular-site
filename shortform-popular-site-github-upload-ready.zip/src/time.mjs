const KST_OFFSET_MS = 9 * 60 * 60 * 1000;

function pad(value) {
  return String(value).padStart(2, '0');
}

export function formatKstDateTime(date = new Date()) {
  const shifted = new Date(date.getTime() + KST_OFFSET_MS);
  return `${shifted.getUTCFullYear()}-${pad(shifted.getUTCMonth() + 1)}-${pad(shifted.getUTCDate())} ${pad(shifted.getUTCHours())}:${pad(shifted.getUTCMinutes())}:${pad(shifted.getUTCSeconds())}`;
}

export function getIsoWeekKst(date = new Date()) {
  const shifted = new Date(date.getTime() + KST_OFFSET_MS);
  const day = shifted.getUTCDay() || 7;
  const thursday = new Date(Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate()));
  thursday.setUTCDate(thursday.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(thursday.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((thursday - yearStart) / 86400000) + 1) / 7);
  return `${thursday.getUTCFullYear()}-W${pad(week)}`;
}

export function weekWindowKst(week = getIsoWeekKst()) {
  const match = /^(\d{4})-W(\d{2})$/.exec(week);
  if (!match) throw new Error('Week must use ISO format YYYY-Www.');
  const year = Number(match[1]);
  const weekNumber = Number(match[2]);
  if (weekNumber < 1 || weekNumber > 53) throw new Error('Invalid ISO week number.');

  const jan4 = new Date(Date.UTC(year, 0, 4));
  const jan4Day = jan4.getUTCDay() || 7;
  const mondayUtcDate = new Date(Date.UTC(year, 0, 4 - jan4Day + 1 + (weekNumber - 1) * 7));
  const startUtc = new Date(mondayUtcDate.getTime() - KST_OFFSET_MS);
  const endUtc = new Date(startUtc.getTime() + 7 * 86400000);
  return {
    week,
    startUtc: startUtc.toISOString(),
    endUtc: endUtc.toISOString(),
    startKst: formatKstDateTime(startUtc),
    endKstExclusive: formatKstDateTime(endUtc)
  };
}
