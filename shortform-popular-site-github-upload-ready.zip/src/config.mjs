function isPlaceholder(value = '') {
  return /change-this|replace-with|secret_xxx|client-id|client-secret|\.\.\.|project-id/i.test(String(value));
}

export function validateRuntimeConfig(env) {
  const mode = env.DATA_MODE || 'mock';
  const production = env.NODE_ENV === 'production';
  const passwordLoginEnabled = env.PASSWORD_LOGIN_ENABLED !== 'false';
  const notionOAuthEnabled = env.NOTION_OAUTH_ENABLED === 'true' || Boolean(env.NOTION_OAUTH_CLIENT_ID || env.NOTION_OAUTH_CLIENT_SECRET);
  const errors = [];
  const warnings = [];

  if (passwordLoginEnabled && (!env.ADMIN_PASSWORD || isPlaceholder(env.ADMIN_PASSWORD) || (production && env.ADMIN_PASSWORD.length < 12))) {
    (production ? errors : warnings).push('ADMIN_PASSWORD must be a non-placeholder value of at least 12 characters when password login is enabled.');
  }
  if (!env.AUTH_SECRET || env.AUTH_SECRET.length < 32 || isPlaceholder(env.AUTH_SECRET)) {
    (production ? errors : warnings).push('AUTH_SECRET must be a non-placeholder value of at least 32 characters.');
  }
  if (!env.CRON_SECRET || env.CRON_SECRET.length < 24 || isPlaceholder(env.CRON_SECRET)) {
    warnings.push('CRON_SECRET is missing, short, or still uses a placeholder; weekly cron will be unavailable.');
  }
  if (production && env.MOCK_PUBLIC_PREVIEW === 'true') {
    errors.push('MOCK_PUBLIC_PREVIEW must be false in production.');
  }

  if (notionOAuthEnabled) {
    for (const name of ['NOTION_OAUTH_CLIENT_ID', 'NOTION_OAUTH_CLIENT_SECRET']) {
      if (!env[name] || isPlaceholder(env[name])) (production ? errors : warnings).push(`${name} is required when Notion OAuth is enabled.`);
    }
    const redirect = env.NOTION_OAUTH_REDIRECT_URI || (env.APP_BASE_URL ? `${String(env.APP_BASE_URL).replace(/\/$/, '')}/api/auth/notion/callback` : '');
    if (!redirect || !/^https:\/\//i.test(redirect) && production) errors.push('Notion OAuth redirect URI must use HTTPS in production.');
    if (production && !env.NOTION_ALLOWED_WORKSPACE_IDS && !env.NOTION_ALLOWED_USER_IDS && !env.NOTION_ALLOWED_EMAILS) {
      errors.push('Configure at least one Notion OAuth allow-list: NOTION_ALLOWED_WORKSPACE_IDS, NOTION_ALLOWED_USER_IDS, or NOTION_ALLOWED_EMAILS.');
    }
  }

  if (!passwordLoginEnabled && !notionOAuthEnabled && production) {
    errors.push('At least one login method must be enabled.');
  }

  if (mode === 'live') {
    for (const name of ['GOOGLE_SERVICE_ACCOUNT_EMAIL', 'GOOGLE_PRIVATE_KEY', 'GOOGLE_SHEET_ID']) {
      if (!env[name] || isPlaceholder(env[name])) errors.push(`${name} is required for DATA_MODE=live.`);
    }
    if (!env.NOTION_API_TOKEN || isPlaceholder(env.NOTION_API_TOKEN)) {
      errors.push('NOTION_API_TOKEN is required for DATA_MODE=live.');
    }
    if (!env.NOTION_CONTENT_DATA_SOURCE_ID) {
      warnings.push('NOTION_CONTENT_DATA_SOURCE_ID is missing; content decisions will only update Sheets.');
    }
  }

  return { mode, production, passwordLoginEnabled, notionOAuthEnabled, errors, warnings };
}
