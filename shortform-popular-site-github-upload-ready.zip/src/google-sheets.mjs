import crypto from 'node:crypto';

const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const SCOPE = 'https://www.googleapis.com/auth/spreadsheets';
let tokenCache = null;

function encodeJson(value) {
  return Buffer.from(JSON.stringify(value)).toString('base64url');
}

function normalizePrivateKey(raw = '') {
  return raw.replace(/^"|"$/g, '').replace(/\\n/g, '\n');
}

function assertConfig(config) {
  if (!config.email || !config.privateKey || !config.sheetId) {
    throw new Error('Google Sheets service-account configuration is incomplete.');
  }
}

async function getAccessToken(config) {
  assertConfig(config);
  if (tokenCache && tokenCache.expiresAt > Date.now() + 60_000) return tokenCache.token;

  const now = Math.floor(Date.now() / 1000);
  const unsigned = `${encodeJson({ alg: 'RS256', typ: 'JWT' })}.${encodeJson({
    iss: config.email,
    scope: SCOPE,
    aud: TOKEN_URL,
    iat: now,
    exp: now + 3600
  })}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  signer.end();
  let signature;
  try {
    signature = signer.sign(normalizePrivateKey(config.privateKey)).toString('base64url');
  } catch (error) {
    throw new Error(`Google private key is invalid: ${error.message}`);
  }

  const response = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion: `${unsigned}.${signature}`
    })
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`Google OAuth failed: ${body.error_description || body.error || response.status}`);
  tokenCache = { token: body.access_token, expiresAt: Date.now() + Number(body.expires_in || 3600) * 1000 };
  return tokenCache.token;
}

async function sheetsFetch(config, path, init = {}) {
  const token = await getAccessToken(config);
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${config.sheetId}${path}`, {
    ...init,
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json',
      ...(init.headers || {})
    }
  });
  const text = await response.text();
  let body = {};
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text }; }
  if (!response.ok) throw new Error(body?.error?.message || `Sheets API ${response.status}`);
  return body;
}

export async function batchGetValues(config, ranges, valueRenderOption = 'FORMATTED_VALUE') {
  const query = new URLSearchParams();
  for (const range of ranges) query.append('ranges', range);
  query.set('majorDimension', 'ROWS');
  query.set('valueRenderOption', valueRenderOption);
  return sheetsFetch(config, `/values:batchGet?${query.toString()}`);
}

export async function getValues(config, range, valueRenderOption = 'FORMATTED_VALUE') {
  const query = new URLSearchParams({ majorDimension: 'ROWS', valueRenderOption });
  return sheetsFetch(config, `/values/${encodeURIComponent(range)}?${query.toString()}`);
}

export async function updateValues(config, range, values) {
  return sheetsFetch(config, `/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`, {
    method: 'PUT',
    body: JSON.stringify({ range, majorDimension: 'ROWS', values })
  });
}

export async function batchUpdateValues(config, data) {
  return sheetsFetch(config, '/values:batchUpdate', {
    method: 'POST',
    body: JSON.stringify({
      valueInputOption: 'USER_ENTERED',
      includeValuesInResponse: true,
      responseValueRenderOption: 'FORMATTED_VALUE',
      data: data.map((entry) => ({ range: entry.range, majorDimension: 'ROWS', values: entry.values }))
    })
  });
}

export async function appendValues(config, range, values) {
  return sheetsFetch(config, `/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`, {
    method: 'POST',
    body: JSON.stringify({ range, majorDimension: 'ROWS', values })
  });
}

export async function readDashboard(config) {
  const result = await batchGetValues(config, [
    'Dashboard!A1:F24',
    'Raw_Content!A1:AJ500',
    'Weekly_Ranking!A1:P100',
    'Pattern_Learning!A1:P100',
    'Run_Log!A1:O300',
    'Settings!A1:D30'
  ]);
  return Object.fromEntries((result.valueRanges || []).map((item) => [item.range.split('!')[0].replaceAll("'", ''), item.values || []]));
}

export async function verifySheetsConnection(config) {
  const result = await getValues(config, 'Settings!A1:B2');
  return { ok: true, range: result.range, rows: result.values?.length || 0 };
}

export function parseUpdatedStartRow(updatedRange = '') {
  const match = /![A-Z]+(\d+):[A-Z]+\d+$/.exec(updatedRange);
  return match ? Number(match[1]) : 0;
}

export function googleConfigFromEnv(env) {
  return {
    email: env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    privateKey: env.GOOGLE_PRIVATE_KEY,
    sheetId: env.GOOGLE_SHEET_ID
  };
}
