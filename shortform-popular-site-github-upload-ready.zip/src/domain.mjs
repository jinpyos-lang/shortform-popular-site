const RAW_HEADERS = [
  'Content ID','Week','Platform','Rank Candidate','URL','Creator','Posted At (KST)','Collected At (KST)',
  'Hours Since Post','Duration Sec','Followers','Views','Likes','Comments','Shares','Saves','Title/Caption','Hashtags',
  'Audio','Category','Views/Hour','Engagement Rate','Share+Save Rate','Follower Efficiency','View Score','Velocity Score',
  'Engagement Score','Share+Save Score','Follower Eff. Score','Total Score','Analysis Status','Notes','Source/Collector',
  'Korean Relevance Score','Eligibility','Thumbnail URL'
];

function num(value) {
  if (value === undefined || value === null || value === '') return 0;
  const cleaned = String(value).replaceAll(',', '').replace('%', '');
  const parsed = Number(cleaned);
  return Number.isFinite(parsed) ? parsed : 0;
}

function percentage(value) {
  if (String(value).includes('%')) return num(value) / 100;
  return num(value);
}

export function rowsToObjects(rows = [], headers = rows[0] || []) {
  return rows.slice(1).filter((row) => row.some((cell) => cell !== '')).map((row, index) => {
    const obj = { _row: index + 2 };
    headers.forEach((header, column) => { obj[header] = row[column] ?? ''; });
    return obj;
  });
}

export function normalizeDashboard(sheetMap, mode = 'live') {
  const rawRows = rowsToObjects(sheetMap.Raw_Content || [], RAW_HEADERS);
  const rankings = rowsToObjects(sheetMap.Weekly_Ranking || []);
  const patterns = rowsToObjects(sheetMap.Pattern_Learning || []);
  const runs = rowsToObjects(sheetMap.Run_Log || []);
  const settings = rowsToObjects(sheetMap.Settings || []);
  const dashboard = sheetMap.Dashboard || [];

  const content = rawRows.map((item) => ({
    row: item._row,
    id: item['Content ID'],
    week: item.Week,
    platform: item.Platform,
    url: item.URL,
    creator: item.Creator,
    title: item['Title/Caption'],
    category: item.Category,
    views: num(item.Views),
    engagementRate: percentage(item['Engagement Rate']),
    totalScore: num(item['Total Score']),
    status: item['Analysis Status'] || 'Pending',
    notes: item.Notes || '',
    source: item['Source/Collector'] || '',
    relevance: num(item['Korean Relevance Score']),
    eligibility: item.Eligibility || 'Review',
    thumbnailUrl: item['Thumbnail URL'] || ''
  }));

  return {
    mode,
    generatedAt: new Date().toISOString(),
    scope: {
      market: dashboard?.[20]?.[1] || '대한민국',
      language: dashboard?.[20]?.[3] || '한국어',
      category: dashboard?.[20]?.[5] || '전 장르',
      output: dashboard?.[21]?.[1] || '플랫폼별 Top 5',
      window: dashboard?.[21]?.[3] || '월~일 KST',
      version: dashboard?.[21]?.[5] || 'v1.0-KR-ALL'
    },
    kpis: {
      rawItems: content.length,
      analyzedItems: content.filter((item) => ['Analyzed', 'Reviewed'].includes(item.status)).length,
      rankedItems: rankings.length,
      patterns: patterns.length,
      eligibleItems: content.filter((item) => item.eligibility === 'Eligible').length,
      reviewItems: content.filter((item) => item.eligibility === 'Review').length
    },
    content: content.sort((a, b) => b.totalScore - a.totalScore),
    rankings,
    patterns,
    runs: runs.reverse(),
    settings
  };
}

export function mockDashboard() {
  return {
    mode: 'mock',
    generatedAt: new Date().toISOString(),
    scope: { market: '대한민국', language: '한국어', category: '전 장르', output: '플랫폼별 Top 5', window: '월~일 KST', version: 'v1.0-KR-ALL' },
    kpis: { rawItems: 18, analyzedItems: 7, rankedItems: 6, patterns: 4, eligibleItems: 12, reviewItems: 4 },
    content: [
      { row: 2, id: 'KR-TT-001', week: '2026-W31', platform: 'TikTok', creator: '@creator_a', title: '결과를 먼저 보여주는 18초 챌린지', category: 'Entertainment', views: 2780000, engagementRate: 0.126, totalScore: 91.4, status: 'Analyzed', relevance: 100, eligibility: 'Eligible', notes: '', url: '#', source: 'Demo', thumbnailUrl: '' },
      { row: 3, id: 'KR-YT-001', week: '2026-W31', platform: 'YouTube Shorts', creator: '채널 B', title: '30초 만에 이해하는 생활 정보', category: 'Education', views: 1840000, engagementRate: 0.094, totalScore: 87.8, status: 'Reviewed', relevance: 98, eligibility: 'Eligible', notes: '', url: '#', source: 'Demo', thumbnailUrl: '' },
      { row: 4, id: 'KR-IG-001', week: '2026-W31', platform: 'Instagram Reels', creator: '@creator_c', title: '반전이 있는 일상 공감 릴스', category: 'Lifestyle', views: 960000, engagementRate: 0.151, totalScore: 85.2, status: 'Pending', relevance: 94, eligibility: 'Review', notes: '광고성 여부 확인', url: '#', source: 'Demo', thumbnailUrl: '' }
    ],
    rankings: [],
    patterns: [
      { 'Pattern Name': '결과 장면 선공개', Category: 'Hook', Platforms: 'TikTok, YouTube Shorts', Confidence: 'Medium', Decision: 'Continue' },
      { 'Pattern Name': '댓글 선택지 유도', Category: 'Comment', Platforms: 'Instagram Reels', Confidence: 'Low', Decision: 'Improve' }
    ],
    runs: [
      { 'Run ID': 'RUN-2026W31-001', 'Run Type': 'Pilot', Week: '2026-W31', Status: 'Planned', 'Items Read': 0, 'Items Accepted': 0, Errors: 0, Notes: 'Credentials pending' }
    ],
    settings: []
  };
}

export function sheetColumnName(index) {
  let n = index;
  let name = '';
  while (n > 0) {
    const mod = (n - 1) % 26;
    name = String.fromCharCode(65 + mod) + name;
    n = Math.floor((n - 1) / 26);
  }
  return name;
}
