# v1.3.0 배포 상태

## 완료

- Notion 계정 기반 로그인 코드
- 영상 썸네일 수집·저장·표시
- Google Sheets AJ 열 확장
- Docker·Render 배포 설정
- 정적 검사와 테스트 15개 통과
- 보안 취약점 0개

## 현재 바로 접근 가능한 주소

Notion 운영 홈페이지:
https://app.notion.com/p/3a93ed6c14e981c19c07dd6edf7dffe8

이 주소는 Notion 워크스페이스 안의 운영·미리보기 페이지입니다.

## 아직 생성되지 않은 주소

Notion OAuth로 로그인하는 독립 HTTPS 홈페이지 주소는 아직 생성되지 않았습니다. 다음 외부 작업은 사용자 소유 계정에서만 할 수 있습니다.

1. Notion Creator Dashboard에서 Public connection 생성
2. OAuth Client ID와 Client Secret 발급
3. Render·Railway·Cloud Run 등 호스팅 프로젝트 생성
4. 환경변수 등록
5. 배포 도메인을 Notion OAuth Redirect URI에 등록

자격 증명이 등록된 뒤 배포하면 로그인 주소는 배포 도메인의 루트(`/`)가 됩니다.
